// Ses Yöneticisi Sınıfı
class SoundManager {
  constructor() {
    this.audioContext = null;
    this.masterVolume = 0.3;
    this.soundEnabled = true;
    this.lastCollisionTime = 0; // Çarpışma ses koruması için
    this.collisionCooldown = 100; // 100ms cooldown
    this.initAudioContext();
  }

  initAudioContext() {
    try {
      this.audioContext = new (window.AudioContext ||
        window.webkitAudioContext)();
    } catch (e) {
      console.warn("Web Audio API desteklenmiyor");
      this.soundEnabled = false;
    }
  }

  // Ses seviyelerini yumuşat
  createOscillator(frequency, type = "sine", duration = 0.1) {
    if (!this.soundEnabled || !this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.setValueAtTime(
      frequency,
      this.audioContext.currentTime
    );
    oscillator.type = type;

    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(
      this.masterVolume * 0.15, // 0.3'ten 0.15'e düşür
      this.audioContext.currentTime + 0.01
    );
    gainNode.gain.exponentialRampToValueAtTime(
      0.001,
      this.audioContext.currentTime + duration
    );

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  createNoise(duration = 0.1, volume = 0.1) {
    if (!this.soundEnabled || !this.audioContext) return;

    const bufferSize = this.audioContext.sampleRate * duration;
    const buffer = this.audioContext.createBuffer(
      1,
      bufferSize,
      this.audioContext.sampleRate
    );
    const output = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.audioContext.createBufferSource();
    const gainNode = this.audioContext.createGain();

    whiteNoise.buffer = buffer;
    whiteNoise.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    gainNode.gain.setValueAtTime(
      this.masterVolume * volume * 0.5, // Volume'u yarıya düşür
      this.audioContext.currentTime
    );
    gainNode.gain.exponentialRampToValueAtTime(
      0.001,
      this.audioContext.currentTime + duration
    );

    whiteNoise.start(this.audioContext.currentTime);
  }

  // Top çarpışma sesi - spam koruması ile
  playBallCollision(velocity) {
    const currentTime = Date.now();

    // Çok yakın zamanda çarpışma sesi çalınmışsa atla
    if (currentTime - this.lastCollisionTime < this.collisionCooldown) {
      return;
    }

    // Minimum hız kontrolü - çok yavaş çarpışmalarda ses çalma
    if (velocity < 2) {
      return;
    }

    this.lastCollisionTime = currentTime;

    const intensity = Math.min(velocity / 15, 1); // 10'dan 15'e çıkar
    const frequency = 250 + intensity * 150; // Daha yumuşak frekans

    this.createOscillator(frequency, "sine", 0.06); // square'den sine'a, süreyi kısalt
    this.createNoise(0.03, intensity * 0.1); // Gürültüyü azalt
  }

  // Diğer sesleri de yumuşat
  playButtonHover() {
    this.createOscillator(600, "sine", 0.03); // 800'den 600'e, süreyi kısalt
  }

  playButtonClick() {
    this.createOscillator(500, "sine", 0.08); // square'den sine'a
    setTimeout(() => this.createOscillator(350, "sine", 0.04), 40);
  }

  playMenuTransition() {
    this.createOscillator(400, "sine", 0.2);
    setTimeout(() => this.createOscillator(600, "sine", 0.15), 100);
    setTimeout(() => this.createOscillator(800, "sine", 0.1), 200);
  }

  playCuePull(pullDistance) {
    const frequency = 180 + pullDistance * 1.5; // Daha yumuşak
    this.createOscillator(frequency, "sine", 0.04); // sawtooth'dan sine'a
  }

  playCueHit(power) {
    const volume = Math.min(power / 100, 1);
    const frequency = 130 + power * 2; // Daha düşük frekans

    this.createOscillator(frequency, "sine", 0.12); // square'den sine'a
    this.createNoise(0.08, volume * 0.2);

    setTimeout(() => {
      this.createOscillator(frequency * 1.5, "sine", 0.06); // 2'den 1.5'e
    }, 15);
  }

  // Top cebe girme sesi
  playBallPocket() {
    // Düşme sesi
    this.createOscillator(400, "sine", 0.1);
    setTimeout(() => this.createOscillator(300, "sine", 0.1), 50);
    setTimeout(() => this.createOscillator(200, "sine", 0.15), 100);

    // Cep sesi
    this.createNoise(0.2, 0.1);
  }

  // Sıra değişim sesi
  playTurnChange() {
    this.createOscillator(600, "triangle", 0.1);
    setTimeout(() => this.createOscillator(800, "triangle", 0.1), 100);
  }

  // Başarı sesi (kazanma)
  playWin() {
    const notes = [523, 659, 784, 1047]; // C, E, G, C oktav
    notes.forEach((note, index) => {
      setTimeout(() => {
        this.createOscillator(note, "sine", 0.3);
      }, index * 150);
    });
  }

  // Hata sesi (foul)
  playFoul() {
    this.createOscillator(200, "sawtooth", 0.3);
    setTimeout(() => this.createOscillator(150, "sawtooth", 0.2), 100);
  }

  // Oyun başlama sesi
  playGameStart() {
    this.createOscillator(440, "sine", 0.2);
    setTimeout(() => this.createOscillator(554, "sine", 0.2), 200);
    setTimeout(() => this.createOscillator(659, "sine", 0.3), 400);
  }

  // Pause sesi
  playPause() {
    this.createOscillator(400, "triangle", 0.1);
    setTimeout(() => this.createOscillator(300, "triangle", 0.1), 100);
  }

  // Resume sesi
  playResume() {
    this.createOscillator(300, "triangle", 0.1);
    setTimeout(() => this.createOscillator(400, "triangle", 0.1), 100);
  }

  // Ses seviyesi ayarlama
  setVolume(volume) {
    this.masterVolume = Math.max(0, Math.min(1, volume));
  }

  // Sesi aç/kapat
  toggleSound() {
    this.soundEnabled = !this.soundEnabled;
    return this.soundEnabled;
  }
}

class BilliardsGame {
  constructor() {
    this.canvas = document.getElementById("gameCanvas");
    this.ctx = this.canvas.getContext("2d");
    this.cueCanvas = document.getElementById("cueCanvas");
    this.cueCtx = this.cueCanvas.getContext("2d");
    this.balls = [];
    this.cueBall = null;
    this.isPlayerTurn = true;
    this.playerGroup = null;
    this.aiGroup = null;
    this.gameState = "aiming";
    this.power = 0;
    this.powerIncreasing = true;
    this.aimAngle = 0;
    this.pockets = [];
    this.gameOver = false;
    this.winner = null;
    this.isCharging = false;
    this.powerInterval = null;
    this.gameStarted = false;
    this.difficulty = "medium";
    this.playerPocketedBalls = [];
    this.aiPocketedBalls = [];
    this.consecutiveShots = false;
    this.placingCueBall = false;
    this.currentLanguage = "tr";
    this.currentTheme = "dark";
    this.sensitivity = 50;
    this.volume = 30; // Yeni volume ayarı (0-100)
    this.isPaused = false;
    this.lastPullDistance = 0; // Ses için
    this.playerNickname = "Player"; // Varsayılan nick

    // Tema ve Istaka seçimleri
    this.selectedTableTheme = "classic";
    this.selectedCueStyle = "classic";

    // Sayfalama sistemi
    this.currentThemePage = 0;
    this.currentCuePage = 0;
    this.itemsPerPage = 6; // 3x2 grid

    // Ses yöneticisi
    this.soundManager = new SoundManager();

    // Gerçek bilardo istaka sistemi
    this.mouseX = 0;
    this.mouseY = 0;
    this.cueStick = {
      visible: false,
      pullDistance: 0,
      maxPull: 150,
    };

    // Tema animasyon değişkenleri
    this.ufoX = this.canvas.width / 2 + 200;
    this.ufoY = this.canvas.height / 2 - 150;
    this.ufoDirection = 1; // 1 sağa, -1 sola
    this.starTwinkle = 0; // Yıldız parıltısı animasyonu için
    this.shurikenRotation = 0; // Shuriken rotasyonu için
    this.flagWaveOffset = 0; // Bayrak dalgalanması için
    this.portalParticles = []; // Rick and Morty portal partikülleri için
    this.snowflakeParticles = []; // South Park kar taneleri için
    this.starfieldParticles = []; // Futurama yıldız alanı için
    this.donutX = Math.random() * this.canvas.width; // Simpsons donut
    this.donutY = -50; // Simpsons donut
    this.chickenX = 150; // Family Guy chicken
    this.chickenY = 150; // Family Guy chicken
    this.chickenVX = 2; // Family Guy chicken velocity
    this.chickenVY = 1; // Family Guy chicken velocity
    this.kiAuraStrength = 0; // Dragon Ball Ki Aura
    this.kiAuraIncreasing = true; // Dragon Ball Ki Aura
    this.leafParticles = []; // Naruto leaf particles
    this.shipX = -100; // One Piece ship
    this.shipY = 100; // One Piece ship

    // Genişletilmiş Tema ve Istaka tanımları
    this.tableThemes = {
      // Dizi ve Anime Temaları - Öncelikli
      rickmorty: {
        name: "Rick and Morty",
        nameEn: "Rick and Morty",
        description: "Wubba Lubba Dub Dub! Portal teması",
        descriptionEn: "Wubba Lubba Dub Dub! Portal theme",
        tableColor: "#0f4c3a",
        tableBorder: "#00ff41",
        feltTexture: "linear-gradient(135deg, #0f4c3a, #1a5c4a)",
      },
      simpsons: {
        name: "The Simpsons",
        nameEn: "The Simpsons",
        description: "D'oh! Springfield Moe's Bar teması",
        descriptionEn: "D'oh! Springfield Moe's Bar theme",
        tableColor: "#ffd700",
        tableBorder: "#ff6b35",
        feltTexture: "linear-gradient(135deg, #ffd700, #ffed4a)",
      },
      southpark: {
        name: "South Park",
        nameEn: "South Park",
        description: "Oh my God! Kar teması",
        descriptionEn: "Oh my God! Snow theme",
        tableColor: "#87ceeb",
        tableBorder: "#ffffff",
        feltTexture: "linear-gradient(135deg, #87ceeb, #b0e0e6)",
      },
      familyguy: {
        name: "Family Guy",
        nameEn: "Family Guy",
        description: "Giggity! Quahog teması",
        descriptionEn: "Giggity! Quahog theme",
        tableColor: "#4169e1",
        tableBorder: "#ff1493",
        feltTexture: "linear-gradient(135deg, #4169e1, #6495ed)",
      },
      futurama: {
        name: "Futurama",
        nameEn: "Futurama",
        description: "Good news everyone! Uzay teması",
        descriptionEn: "Good news everyone! Space theme",
        tableColor: "#ff4500",
        tableBorder: "#00ced1",
        feltTexture: "linear-gradient(135deg, #ff4500, #ff6347)",
      },
      avatar: {
        name: "Avatar",
        nameEn: "Avatar",
        description: "4 element ustası teması",
        descriptionEn: "4 element master theme",
        tableColor: "#228b22",
        tableBorder: "#ffa500",
        feltTexture: "linear-gradient(135deg, #228b22, #32cd32)",
      },
      pokemon: {
        name: "Pokémon",
        nameEn: "Pokémon",
        description: "Gotta catch 'em all! Pokéball teması",
        descriptionEn: "Gotta catch 'em all! Pokéball theme",
        tableColor: "#ff0000",
        tableBorder: "#ffff00",
        feltTexture: "linear-gradient(135deg, #ff0000, #ff4500)",
      },
      dragonball: {
        name: "Dragon Ball",
        nameEn: "Dragon Ball",
        description: "Kamehameha! Saiyan gücü teması",
        descriptionEn: "Saiyan power theme",
        tableColor: "#ff8c00",
        tableBorder: "#ffd700",
        feltTexture: "linear-gradient(135deg, #ff8c00, #ffa500)",
      },
      naruto: {
        name: "Naruto",
        nameEn: "Naruto",
        description: "Dattebayo! Konoha köyü teması",
        descriptionEn: "Dattebayo! Konoha village theme",
        tableColor: "#ff6347",
        tableBorder: "#000080",
        feltTexture: "linear-gradient(135deg, #ff6347, #ff7f50)",
      },
      onepiece: {
        name: "One Piece",
        nameEn: "One Piece",
        description: "Korsan Kralı olmak için! Deniz teması",
        descriptionEn: "To become Pirate King! Sea theme",
        tableColor: "#1e90ff",
        tableBorder: "#ffd700",
        feltTexture: "linear-gradient(135deg, #1e90ff, #4169e1)",
      },
      // Klasik Temalar
      classic: {
        name: "Klasik Yeşil",
        nameEn: "Classic Green",
        description: "Geleneksel bilardo masası teması",
        descriptionEn: "Traditional billiards table theme",
        tableColor: "#0d4f2a",
        tableBorder: "#8b4513",
        feltTexture: "linear-gradient(135deg, #0d4f2a, #0a3d20)",
      },
      ocean: {
        name: "Mavi Okyanus",
        nameEn: "Ocean Blue",
        description: "Sakin mavi tonlarında modern tema",
        descriptionEn: "Modern theme in calm blue tones",
        tableColor: "#1e3a8a",
        tableBorder: "#1e40af",
        feltTexture: "linear-gradient(135deg, #1e3a8a, #1e40af)",
      },
      luxury: {
        name: "Kırmızı Lüks",
        nameEn: "Luxury Red",
        description: "Lüks kırmızı kadife görünümü",
        descriptionEn: "Luxury red velvet appearance",
        tableColor: "#7f1d1d",
        tableBorder: "#dc2626",
        feltTexture: "linear-gradient(135deg, #7f1d1d, #991b1b)",
      },
      professional: {
        name: "Siyah Profesyonel",
        nameEn: "Professional Black",
        description: "Profesyonel turnuva masası",
        descriptionEn: "Professional tournament table",
        tableColor: "#1f2937",
        tableBorder: "#374151",
        feltTexture: "linear-gradient(135deg, #1f2937, #111827)",
      },
      vintage: {
        name: "Ahşap Vintage",
        nameEn: "Vintage Wood",
        description: "Nostaljik ahşap görünümü",
        descriptionEn: "Nostalgic wooden appearance",
        tableColor: "#92400e",
        tableBorder: "#d97706",
        feltTexture: "linear-gradient(135deg, #92400e, #a16207)",
      },
      neon: {
        name: "Neon Cyberpunk",
        nameEn: "Neon Cyberpunk",
        description: "Futuristik neon ışıklı tema",
        descriptionEn: "Futuristic neon-lit theme",
        tableColor: "#0f0f23",
        tableBorder: "#00ffff",
        feltTexture: "linear-gradient(135deg, #0f0f23, #1a1a2e)",
      },
      gold: {
        name: "Altın Saray",
        nameEn: "Golden Palace",
        description: "Lüks altın rengi tema",
        descriptionEn: "Luxury golden theme",
        tableColor: "#b8860b",
        tableBorder: "#ffd700",
        feltTexture: "linear-gradient(135deg, #b8860b, #daa520)",
      },
      silver: {
        name: "Gümüş Elit",
        nameEn: "Silver Elite",
        description: "Şık gümüş rengi tema",
        descriptionEn: "Elegant silver theme",
        tableColor: "#708090",
        tableBorder: "#c0c0c0",
        feltTexture: "linear-gradient(135deg, #708090, #c0c0c0)",
      },
      purple: {
        name: "Mor Kraliyet",
        nameEn: "Royal Purple",
        description: "Kraliyet moru tema",
        descriptionEn: "Royal purple theme",
        tableColor: "#4a148c",
        tableBorder: "#9c27b0",
        feltTexture: "linear-gradient(135deg, #4a148c, #6a1b9a)",
      },
      forest: {
        name: "Yeşil Orman",
        nameEn: "Forest Green",
        description: "Doğal orman yeşili tema",
        descriptionEn: "Natural forest green theme",
        tableColor: "#1b5e20",
        tableBorder: "#4caf50",
        feltTexture: "linear-gradient(135deg, #1b5e20, #2e7d32)",
      },
      ice: {
        name: "Buz Mavisi",
        nameEn: "Ice Blue",
        description: "Soğuk buz mavisi tema",
        descriptionEn: "Cool ice blue theme",
        tableColor: "#b3e5fc",
        tableBorder: "#03a9f4",
        feltTexture: "linear-gradient(135deg, #b3e5fc, #81d4fa)",
      },
      sunset: {
        name: "Gün Batımı",
        nameEn: "Sunset Orange",
        description: "Sıcak turuncu gün batımı",
        descriptionEn: "Warm orange sunset",
        tableColor: "#ff6f00",
        tableBorder: "#ff9800",
        feltTexture: "linear-gradient(135deg, #ff6f00, #ff8f00)",
      },
      rose: {
        name: "Pembe Gül",
        nameEn: "Rose Pink",
        description: "Romantik pembe gül teması",
        descriptionEn: "Romantic rose pink theme",
        tableColor: "#ad1457",
        tableBorder: "#e91e63",
        feltTexture: "linear-gradient(135deg, #ad1457, #c2185b)",
      },
    };

    this.cueStyles = {
      // Dizi ve Anime İstakaları
      rickmorty: {
        name: "Portal İstakası",
        nameEn: "Portal Cue",
        description: "Rick'in portal tabancası tarzı",
        descriptionEn: "Rick's portal gun style",
        gradient: "linear-gradient(90deg, #00ff41, #0f4c3a, #00ff41, #39ff14)",
        tip: "#00ff41",
      },
      simpsons: {
        name: "Homer İstakası",
        nameEn: "Homer Cue",
        description: "Duff bira şişesi tarzı",
        descriptionEn: "Duff beer bottle style",
        gradient: "linear-gradient(90deg, #ffd700, #ff6b35, #ffd700, #ffed4a)",
        tip: "#ff6b35",
      },
      southpark: {
        name: "Kenny İstakası",
        nameEn: "Kenny Cue",
        description: "Turuncu parka tarzı",
        descriptionEn: "Orange parka style",
        gradient: "linear-gradient(90deg, #ff8c00, #87ceeb, #ffffff, #b0e0e6)",
        tip: "#ff8c00",
      },
      familyguy: {
        name: "Peter İstakası",
        nameEn: "Peter Cue",
        description: "Yeşil pantolon tarzı",
        descriptionEn: "Green pants style",
        gradient: "linear-gradient(90deg, #4169e1, #ff1493, #32cd32, #6495ed)",
        tip: "#ff1493",
      },
      futurama: {
        name: "Bender İstakası",
        nameEn: "Bender Cue",
        description: "Robot metal tarzı",
        descriptionEn: "Robot metal style",
        gradient: "linear-gradient(90deg, #c0c0c0, #ff4500, #00ced1, #708090)",
        tip: "#00ced1",
      },
      avatar: {
        name: "Element İstakası",
        nameEn: "Element Cue",
        description: "4 element rengi",
        descriptionEn: "4 element colors",
        gradient: "linear-gradient(90deg, #ff0000, #0000ff, #228b22, #ffa500)",
        tip: "#ffa500",
      },
      pokemon: {
        name: "Pokéball İstakası",
        nameEn: "Pokéball Cue",
        description: "Kırmızı-beyaz Pokéball",
        descriptionEn: "Red-white Pokéball",
        gradient: "linear-gradient(90deg, #ff0000, #ffffff, #ff0000, #ffff00)",
        tip: "#ffff00",
      },
      dragonball: {
        name: "Saiyan İstakası",
        nameEn: "Saiyan Cue",
        description: "Super Saiyan altın aura",
        descriptionEn: "Super Saiyan golden aura",
        gradient: "linear-gradient(90deg, #ffd700, #ff8c00, #ffd700, #ffed4e)",
        tip: "#ffd700",
      },
      naruto: {
        name: "Kunai İstakası",
        nameEn: "Kunai Cue",
        description: "Ninja kunai bıçağı tarzı",
        descriptionEn: "Ninja kunai blade style",
        gradient: "linear-gradient(90deg, #ff6347, #000080, #c0c0c0, #ff7f50)",
        tip: "#000080",
      },
      onepiece: {
        name: "Korsan İstakası",
        nameEn: "Pirate Cue",
        description: "Korsan gemisi yelken tarzı",
        nameEn: "Pirate ship sail style",
        gradient: "linear-gradient(90deg, #1e90ff, #ffd700, #8b4513, #4169e1)",
        tip: "#ffd700",
      },
      // Klasik İstakalar
      classic: {
        name: "Klasik Ahşap",
        nameEn: "Classic Wood",
        description: "Geleneksel ahşap istaka",
        descriptionEn: "Traditional wooden cue",
        gradient: "linear-gradient(90deg, #8b4513, #d2691e, #cd853f, #f4a460)",
        tip: "#654321",
      },
      carbon: {
        name: "Profesyonel Karbon",
        nameEn: "Professional Carbon",
        description: "Modern karbon fiber istaka",
        descriptionEn: "Modern carbon fiber cue",
        gradient: "linear-gradient(90deg, #1f2937, #374151, #4b5563, #6b7280)",
        tip: "#000000",
      },
      ebony: {
        name: "Lüks Abanoz",
        nameEn: "Luxury Ebony",
        description: "Premium abanoz ağacı istaka",
        descriptionEn: "Premium ebony wood cue",
        gradient: "linear-gradient(90deg, #000000, #1f1f1f, #2d2d2d, #404040)",
        tip: "#2d1b14",
      },
      modern: {
        name: "Modern Beyaz",
        nameEn: "Modern White",
        description: "Şık beyaz tasarım istaka",
        descriptionEn: "Elegant white design cue",
        gradient: "linear-gradient(90deg, #ffffff, #f8f9fa, #e9ecef, #dee2e6)",
        tip: "#6c757d",
      },
      maple: {
        name: "Vintage Maple",
        nameEn: "Vintage Maple",
        description: "Klasik akçaağaç istaka",
        descriptionEn: "Classic maple wood cue",
        gradient: "linear-gradient(90deg, #deb887, #f5deb3, #fff8dc, #fffacd)",
        tip: "#8b7355",
      },
      gold: {
        name: "Altın Lüks",
        nameEn: "Golden Luxury",
        description: "Altın kaplama lüks istaka",
        descriptionEn: "Gold-plated luxury cue",
        gradient: "linear-gradient(90deg, #b8860b, #daa520, #ffd700, #ffed4e)",
        tip: "#b8860b",
      },
      silver: {
        name: "Gümüş Elit",
        nameEn: "Silver Elite",
        description: "Gümüş kaplama elit istaka",
        descriptionEn: "Silver-plated elite cue",
        gradient: "linear-gradient(90deg, #708090, #a9a9a9, #c0c0c0, #dcdcdc)",
        tip: "#708090",
      },
      neon: {
        name: "Neon Cyber",
        nameEn: "Neon Cyber",
        description: "Futuristik neon istaka",
        descriptionEn: "Futuristic neon cue",
        gradient: "linear-gradient(90deg, #0f0f23, #1a1a2e, #16213e, #0f3460)",
        tip: "#00ffff",
      },
      crystal: {
        name: "Kristal Cam",
        nameEn: "Crystal Glass",
        description: "Şeffaf kristal cam istaka",
        descriptionEn: "Transparent crystal glass cue",
        gradient: "linear-gradient(90deg, #e3f2fd, #bbdefb, #90caf9, #64b5f6)",
        tip: "#2196f3",
      },
      bamboo: {
        name: "Bambu Doğal",
        nameEn: "Natural Bamboo",
        description: "Ekolojik bambu istaka",
        descriptionEn: "Ecological bamboo cue",
        gradient: "linear-gradient(90deg, #8bc34a, #9ccc65, #aed581, #c5e1a5)",
        tip: "#689f38",
      },
      metal: {
        name: "Metal Çelik",
        nameEn: "Steel Metal",
        description: "Sağlam çelik metal istaka",
        nameEn: "Solid steel metal cue",
        gradient: "linear-gradient(90deg, #37474f, #546e7a, #607d8b, #78909c)",
        tip: "#37474f",
      },
      rainbow: {
        name: "Gökkuşağı",
        nameEn: "Rainbow",
        description: "Renkli gökkuşağı istaka",
        nameEn: "Colorful rainbow cue",
        gradient:
          "linear-gradient(90deg, #f44336, #ff9800, #ffeb3b, #4caf50, #2196f3, #9c27b0)",
        tip: "#f44336",
      },
      fire: {
        name: "Ateş Kızılı",
        nameEn: "Fire Red",
        description: "Ateş kızılı sıcak istaka",
        nameEn: "Fire red hot cue",
        gradient: "linear-gradient(90deg, #d32f2f, #f44336, #ff5722, #ff9800)",
        tip: "#d32f2f",
      },
    };

    this.translations = {
      tr: {
        title: "Bilardist - Profesyonel Bilardo",
        startGame: "Oyuna Başla",
        rules: "Kurallar",
        themes: "Temalar",
        cues: "Istakalar",
        settings: "Ayarlar",
        followUs: "Bizi Takip Edin",
        selectDifficulty: "Zorluk Seviyesi Seçin",
        selectTheme: "Masa Teması Seçin",
        selectCue: "Istaka Seçin",
        gameSettings: "Oyun Ayarları",
        easy: "Kolay",
        medium: "Orta",
        hard: "Zor",
        easyDesc: "AI yavaş ve basit vuruşlar yapar",
        mediumDesc: "AI orta seviye strateji kullanır",
        hardDesc: "AI profesyonel seviyede oynar",
        back: "Geri",
        gameRules: "Oyun Kuralları",
        rule1: "8-Ball Pool kurallarına göre oynanır",
        rule2: "İlk vuruş rastgele belirlenir",
        rule3: "Topları cebe indirmeye çalışın",
        rule4: "Kendi grubunuzu (tam/yarım) belirleyin",
        rule5: "8 numaralı topu en son indirin",
        rule6: "Beyaz topu cebe indirirseniz sıra rakibe geçer",
        backToMenu: "Ana Menüye Dön",
        player: "Oyuncu",
        groupUndetermined: "Grup: Belirlenmedi",
        gameStarted: "Oyun başladı!",
        placeCueBall: "Beyaz topu yerleştirmek için tıklayın",
        power: "Güç",
        pause: "Duraklat",
        quit: "Çıkış",
        playAgain: "Tekrar Oyna",
        mainMenu: "Ana Menü",
        playerTurn: "Sıranız! Nişan alın ve vurun.",
        aiTurn: "AI düşünüyor...",
        solidBalls: "Düz Toplar",
        stripeBalls: "Çizgili Toplar",
        ballPocketed: "numaralı top cebe girdi!",
        shootAgain: "Bir kez daha atın.",
        wrongBall: "Yanlış top! Sıra rakibe geçti.",
        cueBallFoul: "Beyaz top cebe girdi! Beyaz topu yerleştirin.",
        youWin: "Tebrikler! Kazandınız!",
        aiWins: "AI Kazandı!",
        early8Ball: "8 numaralı topu erken indirdiniz!",
        aiEarly8Ball: "AI 8 numaralı topu erken indirdi!",
        gameMenu: "Oyun Menüsü",
        resume: "Devam Et",
        sensitivity: "Hassasiyet",
        backToMainMenu: "Ana Menüye Dön",
        paused: "Oyun Duraklatıldı",
        soundVolume: "Ses Seviyesi",
        soundToggle: "Ses Aç/Kapat",
        volume: "Ses Seviyesi",
        selected: "Seçili",
        soundEnabled: "Ses Açık",
        soundDisabled: "Ses Kapalı",
        enterNickname: "Oyuncu Adınızı Girin",
        nickname: "Oyuncu Adı",
        nicknamePlaceholder: "Adınızı yazın...",
        continueGame: "Oyuna Devam Et",
        invalidNickname: "Lütfen geçerli bir ad girin (2-15 karakter)",
      },
      en: {
        title: "Bilardist - Professional Billiards",
        startGame: "Start Game",
        rules: "Rules",
        themes: "Themes",
        cues: "Cues",
        settings: "Settings",
        followUs: "Follow Us",
        selectDifficulty: "Select Difficulty Level",
        selectTheme: "Select Table Theme",
        selectCue: "Select Cue",
        gameSettings: "Game Settings",
        easy: "Easy",
        medium: "Medium",
        hard: "Hard",
        easyDesc: "AI makes slow and simple shots",
        mediumDesc: "AI uses medium level strategy",
        hardDesc: "AI plays at professional level",
        hardDesc: "AI plays at professional level",
        back: "Back",
        gameRules: "Game Rules",
        rule1: "Played according to 8-Ball Pool rules",
        rule2: "First shot is randomly determined",
        rule3: "Try to pocket the balls",
        rule4: "Determine your group (solid/stripe)",
        rule5: "Pocket the 8-ball last",
        rule6: "If you pocket the cue ball, turn goes to opponent",
        backToMenu: "Back to Main Menu",
        player: "Player",
        groupUndetermined: "Group: Undetermined",
        gameStarted: "Game started!",
        placeCueBall: "Click to place the cue ball",
        power: "Power",
        pause: "Pause",
        quit: "Quit",
        playAgain: "Play Again",
        mainMenu: "Main Menu",
        playerTurn: "Your turn! Aim and shoot.",
        aiTurn: "AI is thinking...",
        solidBalls: "Solid Balls",
        stripeBalls: "Stripe Balls",
        ballPocketed: "ball pocketed!",
        shootAgain: "Shoot again.",
        wrongBall: "Wrong ball! Turn goes to opponent.",
        cueBallFoul: "Cue ball pocketed! Place the cue ball.",
        youWin: "Congratulations! You Win!",
        aiWins: "AI Wins!",
        early8Ball: "You pocketed the 8-ball too early!",
        aiEarly8Ball: "AI pocketed the 8-ball too early!",
        gameMenu: "Game Menu",
        resume: "Resume",
        sensitivity: "Sensitivity",
        backToMainMenu: "Back to Main Menu",
        paused: "Game Paused",
        soundVolume: "Sound Volume",
        soundToggle: "Toggle Sound",
        volume: "Sound Volume",
        selected: "Selected",
        soundEnabled: "Sound On",
        soundDisabled: "Sound Off",
        enterNickname: "Enter Your Nickname",
        nickname: "Nickname",
        nicknamePlaceholder: "Enter your name...",
        continueGame: "Continue to Game",
        invalidNickname: "Please enter a valid name (2-15 characters)",
      },
    };

    this.setupEventListeners();
    this.updateLanguage();
    this.setupPagination();
    this.initializeThemeParticles(); // Yeni eklendi: Tema partiküllerini başlat
    document.body.setAttribute("data-theme", this.currentTheme);
  }

  initializeThemeParticles() {
    // Rick and Morty portal partikülleri
    for (let i = 0; i < 50; i++) {
      this.portalParticles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        radius: Math.random() * 2 + 0.5,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        alpha: Math.random(),
      });
    }

    // South Park kar taneleri
    for (let i = 0; i < 100; i++) {
      this.snowflakeParticles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        radius: Math.random() * 3 + 1,
        vy: Math.random() * 1 + 0.5,
        alpha: Math.random() * 0.5 + 0.5,
      });
    }

    // Futurama yıldız alanı
    for (let i = 0; i < 200; i++) {
      this.starfieldParticles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        size: Math.random() * 2 + 0.5,
        speed: Math.random() * 0.3 + 0.1,
        alpha: Math.random(),
      });
    }

    // Naruto yaprak partikülleri
    for (let i = 0; i < 30; i++) {
      this.leafParticles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        size: Math.random() * 5 + 3,
        speed: Math.random() * 0.5 + 0.2,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.05,
        alpha: Math.random() * 0.5 + 0.5,
      });
    }
  }

  setupPagination() {
    // Tema ve istaka seçim ekranları için sayfalama sistemi
    this.setupSelectionPagination("themeScreen", "theme");
    this.setupSelectionPagination("cueScreen", "cue");
  }

  setupSelectionPagination(screenId, type) {
    const screen = document.getElementById(screenId);
    if (!screen) return;

    const container = screen.querySelector(".selection-container");
    if (!container) return;

    // Scroll butonları ekle
    const leftBtn = document.createElement("div");
    leftBtn.className = "scroll-buttons left";
    leftBtn.innerHTML = `<button class="scroll-btn" id="scrollLeft${screenId}"><i class="fas fa-chevron-left"></i></button>`;

    const rightBtn = document.createElement("div");
    rightBtn.className = "scroll-buttons right";
    rightBtn.innerHTML = `<button class="scroll-btn" id="scrollRight${screenId}"><i class="fas fa-chevron-right"></i></button>`;

    container.style.position = "relative";
    container.appendChild(leftBtn);
    container.appendChild(rightBtn);

    // Sayfa indikatörleri ekle
    const totalItems =
      type === "theme"
        ? Object.keys(this.tableThemes).length
        : Object.keys(this.cueStyles).length;
    const totalPages = Math.ceil(totalItems / this.itemsPerPage);

    const indicators = document.createElement("div");
    indicators.className = "scroll-indicators";

    for (let i = 0; i < totalPages; i++) {
      const indicator = document.createElement("div");
      indicator.className = "scroll-indicator";
      if (i === 0) indicator.classList.add("active");

      indicator.addEventListener("click", () => {
        if (type === "theme") {
          this.currentThemePage = i;
          this.updateThemeDisplay();
        } else {
          this.currentCuePage = i;
          this.updateCueDisplay();
        }
        this.soundManager.playButtonClick();
      });

      indicators.appendChild(indicator);
    }

    container.appendChild(indicators);

    // Sayfa bilgisi ekle
    const pageInfo = document.createElement("div");
    pageInfo.className = "page-info";
    pageInfo.id = `pageInfo${screenId}`;
    container.appendChild(pageInfo);

    // Event listeners
    const leftButton = document.getElementById(`scrollLeft${screenId}`);
    const rightButton = document.getElementById(`scrollRight${screenId}`);

    leftButton.addEventListener("click", () => {
      if (type === "theme") {
        if (this.currentThemePage > 0) {
          this.currentThemePage--;
          this.updateThemeDisplay();
        }
      } else {
        if (this.currentCuePage > 0) {
          this.currentCuePage--;
          this.updateCueDisplay();
        }
      }
      this.soundManager.playButtonClick();
    });

    rightButton.addEventListener("click", () => {
      if (type === "theme") {
        const maxPage =
          Math.ceil(Object.keys(this.tableThemes).length / this.itemsPerPage) -
          1;
        if (this.currentThemePage < maxPage) {
          this.currentThemePage++;
          this.updateThemeDisplay();
        }
      } else {
        const maxPage =
          Math.ceil(Object.keys(this.cueStyles).length / this.itemsPerPage) - 1;
        if (this.currentCuePage < maxPage) {
          this.currentCuePage++;
          this.updateCueDisplay();
        }
      }
      this.soundManager.playButtonClick();
    });

    // İlk görünümü ayarla
    if (type === "theme") {
      this.updateThemeDisplay();
    } else {
      this.updateCueDisplay();
    }
  }

  updateThemeDisplay() {
    const themeItems = document.querySelectorAll(".theme-item");
    const themeKeys = Object.keys(this.tableThemes);
    const startIndex = this.currentThemePage * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;

    // Tüm öğeleri gizle
    themeItems.forEach((item) => {
      item.classList.add("page-hidden");
    });

    // Sadece mevcut sayfadaki öğeleri göster
    themeKeys.slice(startIndex, endIndex).forEach((themeKey) => {
      const element = document.getElementById(`theme-${themeKey}`);
      if (element) {
        element.classList.remove("page-hidden");
      }
    });

    // Buton durumlarını güncelle
    const leftBtn = document.getElementById("scrollLeftthemeScreen");
    const rightBtn = document.getElementById("scrollRightthemeScreen");
    const maxPage = Math.ceil(themeKeys.length / this.itemsPerPage) - 1;

    leftBtn.classList.toggle("disabled", this.currentThemePage === 0);
    rightBtn.classList.toggle("disabled", this.currentThemePage === maxPage);

    // İndikatörleri güncelle
    const indicators = document.querySelectorAll(
      "#themeScreen .scroll-indicator"
    );
    indicators.forEach((indicator, index) => {
      indicator.classList.toggle("active", index === this.currentThemePage);
    });

    // Sayfa bilgisini güncelle
    const pageInfo = document.getElementById("pageInfothemeScreen");
    if (pageInfo) {
      pageInfo.textContent = `${this.currentThemePage + 1} / ${maxPage + 1}`;
    }
  }

  updateCueDisplay() {
    const cueItems = document.querySelectorAll(".cue-item");
    const cueKeys = Object.keys(this.cueStyles);
    const startIndex = this.currentCuePage * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;

    // Tüm öğeleri gizle
    cueItems.forEach((item) => {
      item.classList.add("page-hidden");
    });

    // Sadece mevcut sayfadaki öğeleri göster
    cueKeys.slice(startIndex, endIndex).forEach((cueKey) => {
      const element = document.getElementById(`cue-${cueKey}`);
      if (element) {
        element.classList.remove("page-hidden");
      }
    });

    // Buton durumlarını güncelle
    const leftBtn = document.getElementById("scrollLeftcueScreen");
    const rightBtn = document.getElementById("scrollRightcueScreen");
    const maxPage = Math.ceil(cueKeys.length / this.itemsPerPage) - 1;

    leftBtn.classList.toggle("disabled", this.currentCuePage === 0);
    rightBtn.classList.toggle("disabled", this.currentCuePage === maxPage);

    // İndikatörleri güncelle
    const indicators = document.querySelectorAll(
      "#cueScreen .scroll-indicator"
    );
    indicators.forEach((indicator, index) => {
      indicator.classList.toggle("active", index === this.currentCuePage);
    });

    // Sayfa bilgisini güncelle
    const pageInfo = document.getElementById("pageInfocueScreen");
    if (pageInfo) {
      pageInfo.textContent = `${this.currentCuePage + 1} / ${maxPage + 1}`;
    }
  }

  initializeGame() {
    this.balls = [];
    this.gameOver = false;
    this.winner = null;
    this.playerGroup = null;
    this.aiGroup = null;
    this.gameState = "aiming";
    this.power = 0;
    this.isCharging = false;
    this.gameStarted = true;
    this.playerPocketedBalls = [];
    this.aiPocketedBalls = [];
    this.consecutiveShots = false;
    this.placingCueBall = false;
    this.isPaused = false;

    this.setupBalls();
    this.setupPockets();
    this.applyTableTheme();

    // Nick'i oyun başında ayarla
    document.getElementById("playerNickDisplay").textContent =
      this.playerNickname;

    this.gameLoop();

    this.isPlayerTurn = Math.random() < 0.5;
    this.updateGameStatus();
    this.updateGroupDisplay();

    // Oyun başlama sesi
    this.soundManager.playGameStart();

    if (!this.isPlayerTurn) {
      setTimeout(() => this.aiTurn(), 1000);
    }
  }

  applyTableTheme() {
    const theme = this.tableThemes[this.selectedTableTheme];
    document.documentElement.style.setProperty(
      "--table-color",
      theme.tableColor
    );
    document.documentElement.style.setProperty(
      "--table-border",
      theme.tableBorder
    );

    // Canvas'a tema attribute'u ekle (CSS efektleri için)
    const canvas = document.getElementById("gameCanvas");
    if (canvas) {
      canvas.setAttribute("data-theme", this.selectedTableTheme);
    }
  }

  setupBalls() {
    const centerX = this.canvas.width / 2;
    const centerY = this.canvas.height / 2;

    this.cueBall = {
      x: centerX - 200,
      y: centerY,
      vx: 0,
      vy: 0,
      radius: 16,
      color: "#FFFFFF",
      number: 0,
      type: "cue",
      inPocket: false,
    };
    this.balls.push(this.cueBall);

    const startX = centerX + 150;
    const startY = centerY;
    const ballSpacing = 33;

    const ballPositions = [
      { x: startX, y: startY, number: 1, type: "solid", color: "#FFD700" },
      {
        x: startX + ballSpacing,
        y: startY - ballSpacing / 2,
        number: 2,
        type: "solid",
        color: "#0000FF",
      },
      {
        x: startX + ballSpacing,
        y: startY + ballSpacing / 2,
        number: 3,
        type: "solid",
        color: "#FF0000",
      },
      {
        x: startX + ballSpacing * 2,
        y: startY - ballSpacing,
        number: 4,
        type: "solid",
        color: "#800080",
      },
      {
        x: startX + ballSpacing * 2,
        y: startY,
        number: 8,
        type: "eight",
        color: "#000000",
      },
      {
        x: startX + ballSpacing * 2,
        y: startY + ballSpacing,
        number: 6,
        type: "solid",
        color: "#FFA500",
      },
      {
        x: startX + ballSpacing * 3,
        y: startY - ballSpacing * 1.5,
        number: 7,
        type: "solid",
        color: "#8B0000",
      },
      {
        x: startX + ballSpacing * 3,
        y: startY - ballSpacing / 2,
        number: 9,
        type: "stripe",
        color: "#FFD700",
      },
      {
        x: startX + ballSpacing * 3,
        y: startY + ballSpacing / 2,
        number: 10,
        type: "stripe",
        color: "#0000FF",
      },
      {
        x: startX + ballSpacing * 3,
        y: startY + ballSpacing * 1.5,
        number: 11,
        type: "stripe",
        color: "#FF0000",
      },
      {
        x: startX + ballSpacing * 4,
        y: startY - ballSpacing * 2,
        number: 12,
        type: "stripe",
        color: "#800080",
      },
      {
        x: startX + ballSpacing * 4,
        y: startY - ballSpacing,
        number: 13,
        type: "stripe",
        color: "#FFA500",
      },
      {
        x: startX + ballSpacing * 4,
        y: startY,
        number: 14,
        type: "stripe",
        color: "#008000",
      },
      {
        x: startX + ballSpacing * 4,
        y: startY + ballSpacing,
        number: 15,
        type: "stripe",
        color: "#8B0000",
      },
      {
        x: startX + ballSpacing * 4,
        y: startY + ballSpacing * 2,
        number: 5,
        type: "solid",
        color: "#008000",
      },
    ];

    ballPositions.forEach((pos) => {
      this.balls.push({
        x: pos.x,
        y: pos.y,
        vx: 0,
        vy: 0,
        radius: 16,
        color: pos.color,
        number: pos.number,
        type: pos.type,
        inPocket: false,
      });
    });
  }

  setupPockets() {
    const margin = 25;
    const midX = this.canvas.width / 2;
    const midY = this.canvas.height / 2;

    this.pockets = [
      { x: margin, y: margin, radius: 20 },
      { x: this.canvas.width - margin, y: margin, radius: 20 },
      { x: margin, y: this.canvas.height - margin, radius: 20 },
      {
        x: this.canvas.width - margin,
        y: this.canvas.height - margin,
        radius: 20,
      },
      { x: midX, y: margin - 5, radius: 16 },
      { x: midX, y: this.canvas.height - margin + 5, radius: 16 },
    ];
  }

  setupEventListeners() {
    // Menü butonları için ses efektleri
    const addButtonSounds = (buttonId) => {
      const button = document.getElementById(buttonId);
      if (button) {
        button.addEventListener("mouseenter", () =>
          this.soundManager.playButtonHover()
        );
        button.addEventListener("click", () =>
          this.soundManager.playButtonClick()
        );
      }
    };

    // Tüm butonlara ses efektleri ekle
    const buttonIds = [
      "themeToggle",
      "languageToggle",
      "startGame",
      "showThemes",
      "showCues",
      "showSettings",
      "easyMode",
      "mediumMode",
      "hardMode",
      "backToDifficultyMenu",
      "backToThemeMenu",
      "backToCueMenu",
      "backToSettingsMenu",
      "showRules",
      "backToMenu",
      "pauseGame",
      "quitGame",
      "playAgain",
      "backToMainMenu",
      "resumeGame",
      "pauseBackToMenu",
      "soundToggleBtn",
    ];

    buttonIds.forEach((id) => addButtonSounds(id));

    document.getElementById("themeToggle").addEventListener("click", () => {
      this.toggleTheme();
      this.soundManager.playMenuTransition();
    });

    document.getElementById("languageToggle").addEventListener("click", () => {
      this.toggleLanguage();
      this.soundManager.playMenuTransition();
    });

    document.getElementById("startGame").addEventListener("click", () => {
      this.showScreen("nicknameScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("continueToGame").addEventListener("click", () => {
      this.handleNicknameSubmit();
    });

    document
      .getElementById("nicknameInput")
      .addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          this.handleNicknameSubmit();
        }
      });

    document
      .getElementById("backToNicknameMenu")
      .addEventListener("click", () => {
        this.showScreen("mainMenu");
        this.soundManager.playMenuTransition();
      });

    document.getElementById("showThemes").addEventListener("click", () => {
      this.showScreen("themeScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("showCues").addEventListener("click", () => {
      this.showScreen("cueScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("showSettings").addEventListener("click", () => {
      this.showScreen("settingsScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("easyMode").addEventListener("click", () => {
      this.difficulty = "easy";
      this.showScreen("gameScreen");
      this.initializeGame();
    });

    document.getElementById("mediumMode").addEventListener("click", () => {
      this.difficulty = "medium";
      this.showScreen("gameScreen");
      this.initializeGame();
    });

    document.getElementById("hardMode").addEventListener("click", () => {
      this.difficulty = "hard";
      this.showScreen("gameScreen");
      this.initializeGame();
    });

    document
      .getElementById("backToDifficultyMenu")
      .addEventListener("click", () => {
        this.showScreen("mainMenu");
        this.soundManager.playMenuTransition();
      });

    document.getElementById("backToThemeMenu").addEventListener("click", () => {
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("backToCueMenu").addEventListener("click", () => {
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    document
      .getElementById("backToSettingsMenu")
      .addEventListener("click", () => {
        this.showScreen("mainMenu");
        this.soundManager.playMenuTransition();
      });

    document.getElementById("showRules").addEventListener("click", () => {
      this.showScreen("rulesScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("backToMenu").addEventListener("click", () => {
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    document
      .getElementById("pauseGame")
      .addEventListener("click", () => this.togglePause());
    document.getElementById("quitGame").addEventListener("click", () => {
      this.resetGame();
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("playAgain").addEventListener("click", () => {
      this.showScreen("difficultyScreen");
      this.soundManager.playMenuTransition();
    });

    document.getElementById("backToMainMenu").addEventListener("click", () => {
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    document
      .getElementById("resumeGame")
      .addEventListener("click", () => this.togglePause());
    document.getElementById("pauseBackToMenu").addEventListener("click", () => {
      this.resetGame();
      this.showScreen("mainMenu");
      this.soundManager.playMenuTransition();
    });

    // Ayarlar slider'ları
    document
      .getElementById("sensitivitySlider")
      .addEventListener("input", (e) => {
        this.sensitivity = Number.parseInt(e.target.value);
        document.getElementById("sensitivityValue").textContent =
          this.sensitivity;
      });

    document.getElementById("volumeSlider").addEventListener("input", (e) => {
      this.volume = Number.parseInt(e.target.value);
      document.getElementById("volumeValue").textContent = this.volume;
      this.soundManager.setVolume(this.volume / 100);
    });

    // Ayarlar ekranındaki slider'lar
    document
      .getElementById("settingsSensitivitySlider")
      .addEventListener("input", (e) => {
        this.sensitivity = Number.parseInt(e.target.value);
        document.getElementById("settingsSensitivityValue").textContent =
          this.sensitivity;
      });

    document
      .getElementById("settingsVolumeSlider")
      .addEventListener("input", (e) => {
        this.volume = Number.parseInt(e.target.value);
        document.getElementById("settingsVolumeValue").textContent =
          this.volume;
        this.soundManager.setVolume(this.volume / 100);
      });

    // Ses toggle butonu
    document.getElementById("soundToggleBtn").addEventListener("click", () => {
      this.soundManager.toggleSound();
      this.updateSoundToggleButton();
    });

    // Tema seçim event'leri
    this.setupThemeSelectionEvents();
    this.setupCueSelectionEvents();

    // Game canvas mouse events
    this.canvas.addEventListener("mousemove", (e) => this.handleMouseMove(e));
    this.canvas.addEventListener("mousedown", (e) => this.handleMouseDown(e));
    this.canvas.addEventListener("mouseup", (e) => this.handleMouseUp(e));
    this.canvas.addEventListener("click", (e) => this.handleCanvasClick(e));
    
    // Cue canvas mouse events - aynı eventleri cue canvas'a da ekle
    this.cueCanvas.addEventListener("mousemove", (e) => this.handleMouseMove(e));
    this.cueCanvas.addEventListener("mousedown", (e) => this.handleMouseDown(e));
    this.cueCanvas.addEventListener("mouseup", (e) => this.handleMouseUp(e));
    this.cueCanvas.addEventListener("click", (e) => this.handleCanvasClick(e));

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && this.gameStarted && !this.gameOver) {
        this.togglePause();
      }
    });
  }

  handleNicknameSubmit() {
    const nicknameInput = document.getElementById("nicknameInput");
    const nickname = nicknameInput.value.trim();

    if (nickname.length >= 2 && nickname.length <= 15) {
      this.playerNickname = nickname;
      this.showScreen("difficultyScreen");
      this.soundManager.playMenuTransition();

      // Input'u temizle
      nicknameInput.value = "";
      document.getElementById("nicknameError").classList.add("hidden");
    } else {
      // Hata mesajı göster
      document.getElementById("nicknameError").classList.remove("hidden");
      this.soundManager.playFoul();
    }
  }

  setupThemeSelectionEvents() {
    Object.keys(this.tableThemes).forEach((themeKey) => {
      const element = document.getElementById(`theme-${themeKey}`);
      if (element) {
        element.addEventListener("click", () => {
          this.selectTableTheme(themeKey);
          this.soundManager.playButtonClick();
        });
      }
    });
  }

  setupCueSelectionEvents() {
    Object.keys(this.cueStyles).forEach((cueKey) => {
      const element = document.getElementById(`cue-${cueKey}`);
      if (element) {
        element.addEventListener("click", () => {
          this.selectCueStyle(cueKey);
          this.soundManager.playButtonClick();
        });
      }
    });
  }

  selectTableTheme(themeKey) {
    // Önceki seçimi kaldır
    document.querySelectorAll(".theme-item").forEach((item) => {
      item.classList.remove("selected");
    });

    // Yeni seçimi işaretle
    const selectedElement = document.getElementById(`theme-${themeKey}`);
    if (selectedElement) {
      selectedElement.classList.add("selected");
    }

    this.selectedTableTheme = themeKey;
  }

  selectCueStyle(cueKey) {
    // Önceki seçimi kaldır
    document.querySelectorAll(".cue-item").forEach((item) => {
      item.classList.remove("selected");
    });

    // Yeni seçimi işaretle
    const selectedElement = document.getElementById(`cue-${cueKey}`);
    if (selectedElement) {
      selectedElement.classList.add("selected");
    }

    this.selectedCueStyle = cueKey;
  }

  updateSoundToggleButton() {
    const button = document.getElementById("soundToggleBtn");
    if (button) {
      if (this.soundManager.soundEnabled) {
        button.classList.add("active");
        button.textContent =
          this.translations[this.currentLanguage].soundEnabled;
      } else {
        button.classList.remove("active");
        button.textContent =
          this.translations[this.currentLanguage].soundDisabled;
      }
    }
  }

  togglePause() {
    this.isPaused = !this.isPaused;
    const pauseMenu = document.getElementById("pauseMenu");

    if (this.isPaused) {
      pauseMenu.classList.remove("hidden");
      this.updateGameStatus(this.translations[this.currentLanguage].paused);
      this.soundManager.playPause();
    } else {
      pauseMenu.classList.add("hidden");
      this.updateGameStatus();
      this.soundManager.playResume();
    }
  }

  toggleTheme() {
    this.currentTheme = this.currentTheme === "light" ? "dark" : "light";
    document.body.setAttribute("data-theme", this.currentTheme);
    const themeIcon = document.querySelector("#themeToggle i");
    themeIcon.className =
      this.currentTheme === "light" ? "fas fa-moon" : "fas fa-sun";
  }

  toggleLanguage() {
    this.currentLanguage = this.currentLanguage === "tr" ? "en" : "tr";
    document.getElementById("currentLang").textContent =
      this.currentLanguage.toUpperCase();
    this.updateLanguage();
    this.updateThemeAndCueTexts();
    this.updateSoundToggleButton();
  }

  updateLanguage() {
    const elements = document.querySelectorAll("[data-lang]");
    elements.forEach((element) => {
      const key = element.getAttribute("data-lang");
      if (this.translations[this.currentLanguage][key]) {
        element.textContent = this.translations[this.currentLanguage][key];
      }
    });
  }

  updateThemeAndCueTexts() {
    // Tema metinlerini güncelle
    Object.keys(this.tableThemes).forEach((themeKey) => {
      const titleElement = document.querySelector(
        `#theme-${themeKey} .item-title`
      );
      const descElement = document.querySelector(
        `#theme-${themeKey} .item-description`
      );

      if (titleElement && descElement) {
        const theme = this.tableThemes[themeKey];
        titleElement.textContent =
          this.currentLanguage === "tr" ? theme.name : theme.nameEn;
        descElement.textContent =
          this.currentLanguage === "tr"
            ? theme.description
            : theme.descriptionEn;
      }
    });

    // Istaka metinlerini güncelle
    Object.keys(this.cueStyles).forEach((cueKey) => {
      const titleElement = document.querySelector(`#cue-${cueKey} .item-title`);
      const descElement = document.querySelector(
        `#cue-${cueKey} .item-description`
      );

      if (titleElement && descElement) {
        const cue = this.cueStyles[cueKey];
        titleElement.textContent =
          this.currentLanguage === "tr" ? cue.name : cue.nameEn;
        descElement.textContent =
          this.currentLanguage === "tr" ? cue.description : cue.descriptionEn;
      }
    });
  }

  showScreen(screenId) {
    document
      .querySelectorAll(".screen")
      .forEach((screen) => screen.classList.add("hidden"));
    document.getElementById(screenId).classList.remove("hidden");
    document.getElementById("pauseMenu").classList.add("hidden");
    this.isPaused = false;

    // Ayarlar ekranında değerleri güncelle
    if (screenId === "settingsScreen") {
      document.getElementById("settingsSensitivitySlider").value =
        this.sensitivity;
      document.getElementById("settingsSensitivityValue").textContent =
        this.sensitivity;
      document.getElementById("settingsVolumeSlider").value = this.volume;
      document.getElementById("settingsVolumeValue").textContent = this.volume;
      this.updateSoundToggleButton();
    }

    // Tema/istaka ekranlarında sayfalamayı güncelle
    if (screenId === "themeScreen") {
      this.updateThemeDisplay();
    } else if (screenId === "cueScreen") {
      this.updateCueDisplay();
    }

    if (screenId === "nicknameScreen") {
      // Input'a odaklan
      setTimeout(() => {
        document.getElementById("nicknameInput").focus();
      }, 100);
    }
  }

  handleCanvasClick(e) {
    if (this.isPaused) return;

    // Beyaz top yerleştirme - sadece oyuncu için
    if (
      this.placingCueBall &&
      this.isPlayerTurn &&
      this.gameState === "placing"
    ) {
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      // Diğer toplarla çakışma kontrolü
      let validPosition = true;
      this.balls.forEach((ball) => {
        if (ball !== this.cueBall && !ball.inPocket) {
          const distance = Math.hypot(mouseX - ball.x, mouseY - ball.y);
          if (distance < ball.radius + this.cueBall.radius + 10) {
            validPosition = false;
          }
        }
      });

      // Canvas sınırları kontrolü
      if (
        mouseX < this.cueBall.radius + 10 ||
        mouseX > this.canvas.width - this.cueBall.radius - 10 ||
        mouseY < this.cueBall.radius + 10 ||
        mouseY > this.canvas.height - this.cueBall.radius - 10
      ) {
        validPosition = false;
      }

      if (validPosition) {
        this.cueBall.x = mouseX;
        this.cueBall.y = mouseY;
        this.placingCueBall = false;
        this.gameState = "aiming";
        document.getElementById("cueBallPlacement").classList.add("hidden");
        this.updateGameStatus();
        this.soundManager.playButtonClick(); // Yerleştirme sesi

        // Oyuncu beyaz topu yerleştirdikten sonra oyuncunun sırası
        // AI beyaz topu soktuysa zaten sıra oyuncuda
      }
    }
  }

  handleMouseMove(e) {
    if (
      !this.gameStarted ||
      this.gameOver ||
      this.placingCueBall ||
      this.isPaused
    )
      return;

    const rect = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - rect.left;
    this.mouseY = e.clientY - rect.top;

    if (!this.isPlayerTurn) return;

    if (this.gameState === "aiming") {
      // Nişan açısını hesapla - mouse pozisyonundan cue ball'a doğru
      this.aimAngle = Math.atan2(
        this.cueBall.y - this.mouseY,
        this.cueBall.x - this.mouseX
      );
      this.cueStick.visible = true;
      this.power = 0;
      this.cueStick.pullDistance = 0;
    } else if (this.gameState === "charging") {
      // Istaka çekme mesafesini hesapla
      const distance = Math.hypot(
        this.mouseX - this.cueBall.x,
        this.mouseY - this.cueBall.y
      );
      const minDistance = 50; // Minimum mesafe
      // Sensitivity ayarına göre maksimum çekme mesafesi
      const maxPullDistance = (this.sensitivity / 50) * this.cueStick.maxPull;

      if (distance > minDistance) {
        this.cueStick.pullDistance = Math.min(
          distance - minDistance,
          maxPullDistance
        );
        this.power = (this.cueStick.pullDistance / maxPullDistance) * 100;

        // İstaka çekme sesi (sadece mesafe artarsa)
        if (this.cueStick.pullDistance > this.lastPullDistance + 5) {
          this.soundManager.playCuePull(this.cueStick.pullDistance);
          this.lastPullDistance = this.cueStick.pullDistance;
        }
      } else {
        this.cueStick.pullDistance = 0;
        this.power = 0;
        this.lastPullDistance = 0;
      }

      document.getElementById("powerFill").style.width = this.power + "%"; // Bu satır tekrar aktif edildi
    }
  }

  handleMouseDown(e) {
    if (
      !this.gameStarted ||
      this.gameState !== "aiming" ||
      !this.isPlayerTurn ||
      this.gameOver ||
      this.placingCueBall ||
      this.isPaused
    )
      return;

    this.gameState = "charging";
    this.power = 0;
    this.cueStick.pullDistance = 0;
    this.lastPullDistance = 0;
  }

  handleMouseUp(e) {
    if (
      !this.gameStarted ||
      this.gameState !== "charging" ||
      !this.isPlayerTurn ||
      this.gameOver ||
      this.isPaused
    )
      return;

    if (this.power >= 5) {
      this.shoot();
    } else {
      this.gameState = "aiming";
      this.power = 0;
      this.cueStick.pullDistance = 0;
      this.lastPullDistance = 0;
      document.getElementById("powerFill").style.width = "0%"; // Bu satır tekrar aktif edildi
    }
  }

  shoot() {
    const maxForce = 18;
    const force = (this.power / 100) * maxForce;

    // Vuruş yönü - mouse pozisyonundan cue ball'a doğru (gerçek bilardo)
    this.cueBall.vx = Math.cos(this.aimAngle) * force;
    this.cueBall.vy = Math.sin(this.aimAngle) * force;

    // İstaka vuruş sesi
    this.soundManager.playCueHit(this.power);

    this.gameState = "moving";
    this.power = 0;
    this.consecutiveShots = false;
    this.cueStick.visible = false;
    this.cueStick.pullDistance = 0;
    this.lastPullDistance = 0;
    document.getElementById("powerFill").style.width = "0%"; // Bu satır tekrar aktif edildi
  }

  aiTurn() {
    if (
      this.isPlayerTurn ||
      this.gameState !== "aiming" ||
      this.gameOver ||
      this.isPaused
    )
      return;

    let aiAccuracy, aiPower, aiThinkTime;
    switch (this.difficulty) {
      case "easy":
        aiAccuracy = 0.3 + Math.random() * 0.4;
        aiPower = 8 + Math.random() * 5;
        aiThinkTime = 1500 + Math.random() * 1000;
        break;
      case "medium":
        aiAccuracy = 0.5 + Math.random() * 0.3;
        aiPower = 10 + Math.random() * 7;
        aiThinkTime = 1000 + Math.random() * 500;
        break;
      case "hard":
        aiAccuracy = 0.7 + Math.random() * 0.25;
        aiPower = 12 + Math.random() * 6;
        aiThinkTime = 800 + Math.random() * 400;
        break;
    }

    let targetBalls = this.balls.filter(
      (ball) =>
        !ball.inPocket &&
        ball.type !== "cue" &&
        (this.aiGroup ? ball.type === this.aiGroup : ball.type !== "eight")
    );

    if (targetBalls.length === 0 && this.aiGroup) {
      targetBalls = this.balls.filter(
        (ball) => !ball.inPocket && ball.number === 8
      );
    }

    if (targetBalls.length > 0) {
      const target =
        targetBalls[Math.floor(Math.random() * targetBalls.length)];
      let targetAngle = Math.atan2(
        target.y - this.cueBall.y,
        target.x - this.cueBall.x
      );

      const angleError = (1 - aiAccuracy) * (Math.random() - 0.5) * 0.5;
      targetAngle += angleError;

      setTimeout(() => {
        if (!this.isPaused) {
          this.cueBall.vx = Math.cos(targetAngle) * aiPower;
          this.cueBall.vy = Math.sin(targetAngle) * aiPower;
          this.gameState = "moving";
          this.consecutiveShots = false;

          // AI vuruş sesi
          this.soundManager.playCueHit(aiPower * 5); // AI gücünü ses için ölçekle
        }
      }, aiThinkTime);
    }
  }

  updatePhysics() {
    if (!this.gameStarted || this.isPaused) return;

    let allStopped = true;
    const friction = 0.99;
    const minSpeed = 0.05;

    this.balls.forEach((ball) => {
      if (ball.inPocket) return;

      if (Math.abs(ball.vx) > minSpeed || Math.abs(ball.vy) > minSpeed) {
        ball.vx *= friction;
        ball.vy *= friction;
        allStopped = false;
      } else {
        ball.vx = 0;
        ball.vy = 0;
      }

      ball.x += ball.vx;
      ball.y += ball.vy;

      if (ball.x - ball.radius <= 0) {
        ball.x = ball.radius;
        ball.vx *= -0.8;
      }
      if (ball.x + ball.radius >= this.canvas.width) {
        ball.x = this.canvas.width - ball.radius;
        ball.vx *= -0.8;
      }
      if (ball.y - ball.radius <= 0) {
        ball.y = ball.radius;
        ball.vy *= -0.8;
      }
      if (ball.y + ball.radius >= this.canvas.height) {
        ball.y = this.canvas.height - ball.radius;
        ball.vy *= -0.8;
      }
    });

    this.checkBallCollisions();
    this.checkPockets();

    // Beyaz top yerleştirme durumunda endTurn çağrılmasını engelle
    if (allStopped && this.gameState === "moving") {
      this.gameState = "aiming";
      this.endTurn();
    }
  }

  checkBallCollisions() {
    for (let i = 0; i < this.balls.length; i++) {
      for (let j = i + 1; j < this.balls.length; j++) {
        const ball1 = this.balls[i];
        const ball2 = this.balls[j];

        if (ball1.inPocket || ball2.inPocket) continue;

        const dx = ball2.x - ball1.x;
        const dy = ball2.y - ball1.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < ball1.radius + ball2.radius) {
          // Çarpışma öncesi hızları kaydet
          const preCollisionVelocity1 = Math.hypot(ball1.vx, ball1.vy);
          const preCollisionVelocity2 = Math.hypot(ball2.vx, ball2.vy);

          const angle = Math.atan2(dy, dx);
          const sin = Math.sin(angle);
          const cos = Math.cos(angle);

          const vx1 = ball1.vx * cos + ball1.vy * sin;
          const vy1 = ball1.vy * cos - ball1.vx * sin;
          const vx2 = ball2.vx * cos + ball2.vy * sin;
          const vy2 = ball2.vy * cos - ball2.vx * sin;

          const finalVx1 = vx2;
          const finalVx2 = vx1;

          ball1.vx = finalVx1 * cos - vy1 * sin;
          ball1.vy = vy1 * cos + finalVx1 * sin;
          ball2.vx = finalVx2 * cos - vy2 * sin;
          ball2.vy = vy2 * cos + finalVx2 * sin;

          const overlap = ball1.radius + ball2.radius - distance;
          const separateX = (overlap / 2) * cos;
          const separateY = (overlap / 2) * sin;

          ball1.x -= separateX;
          ball1.y -= separateY;
          ball2.x += separateX;
          ball2.y += separateY;

          ball1.vx *= 0.95;
          ball1.vy *= 0.95;
          ball2.vx *= 0.95;
          ball2.vy *= 0.95;

          // Çarpışma sesi - en yüksek hızı kullan
          const maxVelocity = Math.max(
            preCollisionVelocity1,
            preCollisionVelocity2
          );
          this.soundManager.playBallCollision(maxVelocity);
        }
      }
    }
  }

  checkPockets() {
    this.balls.forEach((ball) => {
      if (ball.inPocket) return;

      this.pockets.forEach((pocket) => {
        const distance = Math.hypot(ball.x - pocket.x, ball.y - pocket.y);
        if (distance < pocket.radius - 3) {
          ball.inPocket = true;
          ball.vx = 0;
          ball.vy = 0;
          this.handleBallPocketed(ball);

          // Top cebe girme sesi
          this.soundManager.playBallPocket();
        }
      });
    });
  }

  handleBallPocketed(ball) {
    if (ball.type === "cue") {
      this.updateGameStatus(
        this.translations[this.currentLanguage].cueBallFoul
      );
      this.soundManager.playFoul(); // Foul sesi

      // Beyaz topu kim soktu?
      const aiSoktu = !this.isPlayerTurn;

      ball.inPocket = false;
      this.placingCueBall = true;
      this.gameState = "placing";

      if (aiSoktu) {
        // AI soktu - Oyuncu yerleştirir
        this.isPlayerTurn = true;
        document.getElementById("cueBallPlacement").classList.remove("hidden");
      } else {
        // Oyuncu soktu - AI yerleştirir
        this.isPlayerTurn = false;
        this.aiPlaceCueBall();
      }

      return;
    } else if (ball.number === 8) {
      this.handle8BallPocketed();
    } else {
      this.handleNormalBallPocketed(ball);
    }
  }

  aiPlaceCueBall() {
    // AI beyaz topu otomatik olarak en mantıklı yere yerleştirir
    let bestPosition = null;
    let maxDistance = 0;

    // Masanın sol yarısında en uzak noktayı bul
    for (let x = 50; x < this.canvas.width / 3; x += 20) {
      for (let y = 50; y < this.canvas.height - 50; y += 20) {
        let validPosition = true;
        let minDistanceToOtherBalls = Number.POSITIVE_INFINITY;

        // Diğer toplarla çakışma kontrolü
        this.balls.forEach((otherBall) => {
          if (otherBall !== this.cueBall && !otherBall.inPocket) {
            const distance = Math.hypot(x - otherBall.x, y - otherBall.y);
            if (distance < otherBall.radius + this.cueBall.radius + 20) {
              validPosition = false;
            }
            minDistanceToOtherBalls = Math.min(
              minDistanceToOtherBalls,
              distance
            );
          }
        });

        if (validPosition && minDistanceToOtherBalls > maxDistance) {
          maxDistance = minDistanceToOtherBalls;
          bestPosition = { x, y };
        }
      }
    }

    if (bestPosition) {
      this.cueBall.x = bestPosition.x;
      this.cueBall.y = bestPosition.y;
    } else {
      // Varsayılan pozisyon
      this.cueBall.x = this.canvas.width / 4;
      this.cueBall.y = this.canvas.height / 2;
    }

    // ÖNEMLİ: Bu satırları ekleyin
    this.placingCueBall = false;
    this.gameState = "aiming";
    document.getElementById("cueBallPlacement").classList.add("hidden");

    this.updateGameStatus(); // Durumu güncelle

    // AI topu yerleştirdikten sonra sıra kimde?
    if (!this.isPlayerTurn) {
      // AI'ın sırası - AI oynamaya devam eder
      setTimeout(() => this.aiTurn(), 1000);
    }
    // Eğer oyuncunun sırası ise, oyuncu manuel oynayacak
  }

  resetGame() {
    this.gameStarted = false;
    this.gameOver = false;
    this.balls = [];
    this.cueBall = null;
    this.isPlayerTurn = true;
    this.playerGroup = null;
    this.aiGroup = null;
    this.gameState = "aiming";
    this.power = 0;
    this.powerIncreasing = true;
    this.aimAngle = 0;
    this.winner = null;
    this.isCharging = false;
    this.playerPocketedBalls = [];
    this.aiPocketedBalls = [];
    this.consecutiveShots = false;
    this.placingCueBall = false;
    this.isPaused = false;
    this.lastPullDistance = 0;

    document.getElementById("powerFill").style.width = "0%"; // Bu satır tekrar aktif edildi
    document.getElementById("cueBallPlacement").classList.add("hidden");
    document.getElementById("pauseMenu").classList.add("hidden");

    document.getElementById("playerGroup").textContent =
      this.translations[this.currentLanguage].groupUndetermined;
    document.getElementById("aiGroup").textContent =
      this.translations[this.currentLanguage].groupUndetermined;
    document.getElementById("playerBalls").innerHTML = "";
    document.getElementById("aiBalls").innerHTML = "";

    // Nick'i oyun içinde göster
    document.getElementById("playerNickDisplay").textContent =
      this.playerNickname;
    document.getElementById(
      "currentPlayer"
    ).textContent = `${this.playerNickname}`;
    document.getElementById("gameStatus").textContent =
      this.translations[this.currentLanguage].gameStarted;

    if (this.powerInterval) {
      clearInterval(this.powerInterval);
      this.powerInterval = null;
    }
  }

  handle8BallPocketed() {
    if (this.isPlayerTurn) {
      // Oyuncu 8-ball'ı soktu
      if (!this.playerGroup) {
        // Henüz grup belirlenmemiş - oyunu kaybeder
        this.endGame(
          this.translations[this.currentLanguage].early8Ball +
            " " +
            this.translations[this.currentLanguage].aiWins,
          false
        );
        return;
      }

      const playerBallsRemaining = this.balls.filter(
        (ball) =>
          !ball.inPocket &&
          ball.type !== "cue" &&
          ball.type !== "eight" &&
          ball.type === this.playerGroup
      ).length;

      if (playerBallsRemaining === 0) {
        // Tüm topları sokmuş - kazandı
        this.endGame(this.translations[this.currentLanguage].youWin, true);
      } else {
        // Henüz tüm topları sokmamış - kaybetti
        this.endGame(
          this.translations[this.currentLanguage].early8Ball +
            " " +
            this.translations[this.currentLanguage].aiWins,
          false
        );
      }
    } else {
      // AI 8-ball'ı soktu
      if (!this.aiGroup) {
        // Henüz grup belirlenmemiş - AI kaybeder
        this.endGame(
          this.translations[this.currentLanguage].aiEarly8Ball +
            " " +
            this.translations[this.currentLanguage].youWin,
          true
        );
        return;
      }

      const aiBallsRemaining = this.balls.filter(
        (ball) =>
          !ball.inPocket &&
          ball.type !== "cue" &&
          ball.type !== "eight" &&
          ball.type === this.aiGroup
      ).length;

      if (aiBallsRemaining === 0) {
        // AI tüm topları sokmuş - AI kazandı
        this.endGame(this.translations[this.currentLanguage].aiWins, false);
      } else {
        // AI henüz tüm topları sokmamış - oyuncu kazandı
        this.endGame(
          this.translations[this.currentLanguage].aiEarly8Ball +
            " " +
            this.translations[this.currentLanguage].youWin,
          true
        );
      }
    }
  }

  handleNormalBallPocketed(ball) {
    // Grup belirleme
    if (!this.playerGroup && !this.aiGroup) {
      if (this.isPlayerTurn) {
        this.playerGroup = ball.type;
        this.aiGroup = ball.type === "solid" ? "stripe" : "solid";
      } else {
        this.aiGroup = ball.type;
        this.playerGroup = ball.type === "solid" ? "stripe" : "solid";
      }
      this.updateGroupDisplay();
    }

    const correctGroup = this.isPlayerTurn ? this.playerGroup : this.aiGroup;

    if (ball.type === correctGroup) {
      // Doğru top soktu - puan al ve devam et
      if (this.isPlayerTurn) {
        this.playerPocketedBalls.push(ball);
      } else {
        this.aiPocketedBalls.push(ball);
      }
      this.consecutiveShots = true;
      this.updateGameStatus(
        `${ball.number} ${
          this.translations[this.currentLanguage].ballPocketed
        } ${this.translations[this.currentLanguage].shootAgain}`
      );
      this.updateBallsDisplay();
    } else {
      // Yanlış top soktu - sıra değişimi
      this.updateGameStatus(this.translations[this.currentLanguage].wrongBall);
      this.consecutiveShots = false; // Sıra değişecek
      this.soundManager.playFoul(); // Yanlış top sesi
      // Top kimseye verilmez, sadece cebe gider
    }
  }

  endTurn() {
    if (!this.consecutiveShots) {
      this.isPlayerTurn = !this.isPlayerTurn;
      this.soundManager.playTurnChange(); // Sıra değişim sesi
    }

    this.updateGameStatus();

    if (
      !this.isPlayerTurn &&
      this.gameState === "aiming" &&
      !this.gameOver &&
      !this.isPaused
    ) {
      setTimeout(() => this.aiTurn(), 1000);
    }
  }

  updateGameStatus(message = null) {
    const statusElement = document.getElementById("gameStatus");

    if (message) {
      statusElement.textContent = message;
    } else {
      statusElement.textContent = this.isPlayerTurn
        ? this.translations[this.currentLanguage].playerTurn
        : this.translations[this.currentLanguage].aiTurn;
    }

    // Nick'i kullan
    document.getElementById("currentPlayer").textContent = `${
      this.isPlayerTurn ? this.playerNickname : "AI"
    }`;
  }

  updateGroupDisplay() {
    const playerGroupElement = document.getElementById("playerGroup");
    const aiGroupElement = document.getElementById("aiGroup");

    if (this.playerGroup) {
      const playerGroupName =
        this.playerGroup === "solid"
          ? this.translations[this.currentLanguage].solidBalls
          : this.translations[this.currentLanguage].stripeBalls;
      const aiGroupName =
        this.aiGroup === "solid"
          ? this.translations[this.currentLanguage].solidBalls
          : this.translations[this.currentLanguage].stripeBalls;

      playerGroupElement.textContent = `${playerGroupName}`;
      aiGroupElement.textContent = `${aiGroupName}`;
    } else {
      playerGroupElement.textContent =
        this.translations[this.currentLanguage].groupUndetermined;
      aiGroupElement.textContent =
        this.translations[this.currentLanguage].groupUndetermined;
    }
  }

  updateBallsDisplay() {
    const playerBallsElement = document.getElementById("playerBalls");
    const aiBallsElement = document.getElementById("aiBalls");

    playerBallsElement.innerHTML = "";
    this.playerPocketedBalls.forEach((ball) => {
      const ballDiv = document.createElement("div");
      ballDiv.className = "ball-item";
      ballDiv.style.backgroundColor = ball.color;
      ballDiv.style.color = ball.color === "#000000" ? "#FFFFFF" : "#000000";
      ballDiv.textContent = ball.number;
      playerBallsElement.appendChild(ballDiv);
    });

    aiBallsElement.innerHTML = "";
    this.aiPocketedBalls.forEach((ball) => {
      const ballDiv = document.createElement("div");
      ballDiv.className = "ball-item";
      ballDiv.style.backgroundColor = ball.color;
      ballDiv.style.color = ball.color === "#000000" ? "#FFFFFF" : "#000000";
      ballDiv.textContent = ball.number;
      aiBallsElement.appendChild(ballDiv);
    });
  }

  endGame(message, playerWon = false) {
    this.gameOver = true;
    this.gameStarted = false;

    document.getElementById("gameResult").textContent = message;
    document.getElementById(
      "finalScore"
    ).textContent = `${this.playerNickname}: ${this.playerPocketedBalls.length} | AI: ${this.aiPocketedBalls.length}`;

    const resultIcon = document.getElementById("resultIcon");
    if (playerWon) {
      resultIcon.className = "fas fa-trophy";
      resultIcon.style.color = "var(--success-color)";
      this.soundManager.playWin(); // Kazanma sesi
    } else {
      resultIcon.className = "fas fa-times-circle";
      resultIcon.style.color = "var(--accent-color)";
      this.soundManager.playFoul(); // Kaybetme sesi
    }

    setTimeout(() => {
      this.showScreen("gameOverScreen");
    }, 2000);
  }

  render() {
    if (!this.gameStarted) return;

    // Seçilen tema rengini uygula
    const theme = this.tableThemes[this.selectedTableTheme];
    this.ctx.fillStyle = theme.tableColor;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Tema bazlı özel efektler ve desenler
    this.renderThemeEffects();

    // Masa kenar çizgisi
    this.ctx.strokeStyle = theme.tableBorder;
    this.ctx.lineWidth = 4;
    this.ctx.strokeRect(2, 2, this.canvas.width - 4, this.canvas.height - 4);

    // Orta çizgi
    this.ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    this.ctx.lineWidth = 2;
    this.ctx.setLineDash([10, 5]);
    this.ctx.beginPath();
    this.ctx.moveTo(this.canvas.width / 4, 0);
    this.ctx.lineTo(this.canvas.width / 4, this.canvas.height);
    this.ctx.stroke();
    this.ctx.setLineDash([]);

    // Cepler
    this.ctx.fillStyle = "#000000";
    this.pockets.forEach((pocket) => {
      this.ctx.beginPath();
      this.ctx.arc(pocket.x, pocket.y, pocket.radius, 0, Math.PI * 2);
      this.ctx.fill();

      this.ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
      this.ctx.beginPath();
      this.ctx.arc(
        pocket.x + 2,
        pocket.y + 2,
        pocket.radius - 2,
        0,
        Math.PI * 2
      );
      this.ctx.fill();
      this.ctx.fillStyle = "#000000";
    });

    // Topları çiz
    this.balls.forEach((ball) => {
      if (ball.inPocket) return;

      this.ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
      this.ctx.beginPath();
      this.ctx.arc(ball.x + 4, ball.y + 4, ball.radius, 0, Math.PI * 2);
      this.ctx.fill();

      const gradient = this.ctx.createRadialGradient(
        ball.x - ball.radius * 0.3,
        ball.y - ball.radius * 0.3,
        0,
        ball.x,
        ball.y,
        ball.radius
      );

      if (ball.type === "cue") {
        gradient.addColorStop(0, "#FFFFFF");
        gradient.addColorStop(0.7, "#F8F8F8");
        gradient.addColorStop(1, "#E0E0E0");
      } else {
        gradient.addColorStop(0, this.lightenColor(ball.color, 40));
        gradient.addColorStop(0.7, ball.color);
        gradient.addColorStop(1, this.darkenColor(ball.color, 20));
      }

      this.ctx.fillStyle = gradient;
      this.ctx.beginPath();
      this.ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
      this.ctx.fill();

      this.ctx.strokeStyle = "#333";
      this.ctx.lineWidth = 2;
      this.ctx.stroke();

      this.ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      this.ctx.beginPath();
      this.ctx.arc(
        ball.x - ball.radius * 0.4,
        ball.y - ball.radius * 0.4,
        ball.radius * 0.35,
        0,
        Math.PI * 2
      );
      this.ctx.fill();

      if (ball.type !== "cue") {
        this.ctx.fillStyle = ball.color === "#000000" ? "#FFFFFF" : "#000000";
        this.ctx.font = "bold 16px Arial";
        this.ctx.textAlign = "center";
        this.ctx.strokeStyle = ball.color === "#000000" ? "#000000" : "#FFFFFF";
        this.ctx.lineWidth = 0.8;
        this.ctx.strokeText(ball.number, ball.x, ball.y + 5);
        this.ctx.fillText(ball.number, ball.x, ball.y + 5);
      }

      if (ball.type === "stripe") {
        this.ctx.strokeStyle = "#FFFFFF";
        this.ctx.lineWidth = 4;
        this.ctx.beginPath();
        this.ctx.moveTo(ball.x - ball.radius + 4, ball.y);
        this.ctx.lineTo(ball.x + ball.radius - 4, ball.y);
        this.ctx.stroke();

        this.ctx.strokeStyle = "rgba(0, 0, 0, 0.3)";
        this.ctx.lineWidth = 4;
        this.ctx.beginPath();
        this.ctx.moveTo(ball.x - ball.radius + 4, ball.y + 1);
        this.ctx.lineTo(ball.x + ball.radius - 4, ball.y + 1);
        this.ctx.stroke();
      }
    });

    // Beyaz top yerleştirme göstergesi
    if (this.placingCueBall) {
      this.ctx.strokeStyle = "rgba(255, 255, 255, 0.7)";
      this.ctx.lineWidth = 3;
      this.ctx.setLineDash([8, 4]);
      this.ctx.beginPath();
      this.ctx.arc(
        this.cueBall.x,
        this.cueBall.y,
        this.cueBall.radius + 8,
        0,
        Math.PI * 2
      );
      this.ctx.stroke();
      this.ctx.setLineDash([]);
    }

    if (this.isPaused) {
      this.ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
      this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

      this.ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
      this.ctx.font = "bold 48px Arial";
      this.ctx.textAlign = "center";
      this.ctx.fillText(
        this.translations[this.currentLanguage].paused,
        this.canvas.width / 2,
        this.canvas.height / 2
      );
    }

    this.renderCue();
  }

  renderCue() {
    this.cueCtx.clearRect(0, 0, this.cueCanvas.width, this.cueCanvas.height);

    // Istaka sadece oyuncunun sırasında ve nişan alırken veya güç şarj ederken görünür olmalı
    if (
      !this.gameStarted ||
      this.gameOver ||
      this.placingCueBall ||
      this.isPaused ||
      !this.isPlayerTurn ||
      (this.gameState !== "aiming" && this.gameState !== "charging") ||
      !this.cueBall ||
      this.cueBall.inPocket
    ) {
      return;
    }

    const cueBallX = this.cueBall.x;
    const cueBallY = this.cueBall.y;

    // Istaka pozisyonunu hesapla
    const cueLength = 300; // Istaka uzunluğu
    const cueOffset = 20; // Topa olan uzaklık
    const pullOffset = this.cueStick.pullDistance; // Çekme mesafesi

    const startX =
      cueBallX - Math.cos(this.aimAngle) * (cueOffset + pullOffset);
    const startY =
      cueBallY - Math.sin(this.aimAngle) * (cueOffset + pullOffset);
    const endX = startX - Math.cos(this.aimAngle) * cueLength;
    const endY = startY - Math.sin(this.aimAngle) * cueLength;

    // Istaka çizimi
    const cueStyle = this.cueStyles[this.selectedCueStyle];
    const gradient = this.cueCtx.createLinearGradient(
      startX,
      startY,
      endX,
      endY
    );

    // Gradient için renk duraklarını ayrıştır
    const colors = cueStyle.gradient.match(/#[0-9a-fA-F]{6}|rgba?\([^)]+\)/g);
    if (colors && colors.length > 0) {
      const step = 1 / (colors.length - 1);
      colors.forEach((color, index) => {
        gradient.addColorStop(index * step, color);
      });
    } else {
      // Varsayılan renkler (eğer gradient regex eşleşmezse)
      gradient.addColorStop(0, "#8B4513");
      gradient.addColorStop(1, "#F4A460");
    }

    this.cueCtx.strokeStyle = gradient;
    this.cueCtx.lineWidth = 10; // Istaka kalınlığını artırdım
    this.cueCtx.lineCap = "round";

    // Istakaya gölge efekti ekle
    this.cueCtx.shadowColor = "rgba(0, 0, 0, 0.5)";
    this.cueCtx.shadowBlur = 8;
    this.cueCtx.shadowOffsetX = 3;
    this.cueCtx.shadowOffsetY = 3;

    this.cueCtx.beginPath();
    this.cueCtx.moveTo(startX, startY);
    this.cueCtx.lineTo(endX, endY);
    this.cueCtx.stroke();

    // Gölgeyi sıfırla, böylece diğer çizimler etkilenmez
    this.cueCtx.shadowColor = "transparent";
    this.cueCtx.shadowBlur = 0;
    this.cueCtx.shadowOffsetX = 0;
    this.cueCtx.shadowOffsetY = 0;

    // Istaka ucu
    this.cueCtx.fillStyle = cueStyle.tip;
    this.cueCtx.beginPath();
    this.cueCtx.arc(startX, startY, 6, 0, Math.PI * 2); // Uç boyutunu büyüttüm
    this.cueCtx.fill();

    // Nişan çizgisi (sadece nişan alırken)
    if (this.gameState === "aiming") {
      this.cueCtx.strokeStyle = "rgba(255, 255, 255, 0.5)";
      this.cueCtx.lineWidth = 1;
      this.cueCtx.setLineDash([5, 5]);
      this.cueCtx.beginPath();
      this.cueCtx.moveTo(cueBallX, cueBallY);
      this.cueCtx.lineTo(
        cueBallX + Math.cos(this.aimAngle) * 500,
        cueBallY + Math.sin(this.aimAngle) * 500
      );
      this.cueCtx.stroke();
      this.cueCtx.setLineDash([]);
    }

    // Güç göstergesi (cueCanvas üzerinde) - Bu kısım kaldırıldı.
    // if (this.gameState === "charging") {
    //   const powerBarWidth = 150;
    //   const powerBarHeight = 20;
    //   const powerBarX = this.cueCanvas.width / 2 - powerBarWidth / 2;
    //   const powerBarY = this.cueCanvas.height - 50;

    //   // Güç çubuğu arka planı
    //   this.cueCtx.fillStyle = "rgba(0, 0, 0, 0.5)";
    //   this.cueCtx.fillRect(powerBarX, powerBarY, powerBarWidth, powerBarHeight);

    //   // Güç çubuğu dolumu
    //   const currentPowerWidth = (this.power / 100) * powerBarWidth;
    //   const powerGradient = this.cueCtx.createLinearGradient(powerBarX, 0, powerBarX + powerBarWidth, 0);
    //   powerGradient.addColorStop(0, "#00FF00");
    //   powerGradient.addColorStop(0.5, "#FFFF00");
    //   powerGradient.addColorStop(1, "#FF0000");
    //   this.cueCtx.fillStyle = powerGradient;
    //   this.cueCtx.fillRect(powerBarX, powerBarY, currentPowerWidth, powerBarHeight);

    //   // Güç yüzdesi metni
    //   this.cueCtx.fillStyle = "#FFFFFF";
    //   this.cueCtx.font = "bold 14px Arial"; // Yazı boyutunu büyüttüm
    //   this.cueCtx.textAlign = "center";
    //   this.cueCtx.fillText(
    //     `${Math.round(this.power)}%`,
    //     powerBarX + powerBarWidth / 2,
    //     powerBarY + powerBarHeight / 2 + 5 // Metni ortaladım
    //   );
    // }
  }

  renderThemeEffects() {
    // Animasyon değişkenlerini güncelle
    const now = Date.now();
    this.starTwinkle = (Math.sin(now * 0.005) + 1) / 2; // 0 ile 1 arasında değişir
    this.shurikenRotation = (now * 0.002) % (Math.PI * 2); // Sürekli döner
    this.flagWaveOffset = Math.sin(now * 0.003) * 5; // Bayrak dalgalanması

    // UFO hareketi
    const ufoSpeed = 0.8; // UFO hızını artırdım
    this.ufoX += this.ufoDirection * ufoSpeed;
    if (this.ufoX > this.canvas.width + 50) {
      this.ufoX = -50;
    }

    // Donut hareketi (Simpsons)
    this.donutY += 0.5; // Yavaşça aşağı düşer
    if (this.donutY > this.canvas.height + 50) {
      this.donutY = -50;
      this.donutX = Math.random() * this.canvas.width;
    }

    // Chicken hareketi (Family Guy)
    this.chickenX += this.chickenVX;
    this.chickenY += this.chickenVY;
    if (this.chickenX < 0 || this.chickenX > this.canvas.width) {
      this.chickenVX *= -1;
    }
    if (this.chickenY < 0 || this.chickenY > this.canvas.height) {
      this.chickenVY *= -1;
    }

    // Ki Aura (Dragon Ball)
    if (this.kiAuraIncreasing) {
      this.kiAuraStrength += 0.02;
      if (this.kiAuraStrength > 1) {
        this.kiAuraStrength = 1;
        this.kiAuraIncreasing = false;
      }
    } else {
      this.kiAuraStrength -= 0.02;
      if (this.kiAuraStrength < 0) {
        this.kiAuraStrength = 0;
        this.kiAuraIncreasing = true;
      }
    }

    // One Piece Ship
    this.shipX += 0.5; // Sağa doğru hareket
    if (this.shipX > this.canvas.width + 100) {
      this.shipX = -100;
      this.shipY = 50 + Math.random() * (this.canvas.height - 100);
    }

    switch (this.selectedTableTheme) {
      case "rickmorty":
        this.renderRickMortyTheme();
        break;
      case "simpsons":
        this.renderSimpsonsTheme();
        break;
      case "southpark":
        this.renderSouthParkTheme();
        break;
      case "familyguy":
        this.renderFamilyGuyTheme();
        break;
      case "futurama":
        this.renderFuturamaTheme();
        break;
      case "avatar":
        this.renderAvatarTheme();
        break;
      case "pokemon":
        this.renderPokemonTheme();
        break;
      case "dragonball":
        this.renderDragonBallTheme();
        break;
      case "naruto":
        this.renderNarutoTheme();
        break;
      case "onepiece":
        this.renderOnePieceTheme();
        break;
      case "neon":
        this.renderNeonTheme();
        break;
      case "gold":
        this.renderGoldTheme();
        break;
      case "silver":
        this.renderSilverTheme();
        break;
    }
  }

  renderRickMortyTheme() {
    // Portal efekti
    const centerX = this.canvas.width / 2;
    const centerY = this.canvas.height / 2;
    const portalPulse = (Math.sin(Date.now() * 0.008) + 1) / 2; // Daha hızlı nabız efekti

    // Portal gradient
    const portalGradient = this.ctx.createRadialGradient(
      centerX,
      centerY,
      0,
      centerX,
      centerY,
      100 + portalPulse * 30 // Daha belirgin büyüme
    );
    portalGradient.addColorStop(
      0,
      `rgba(0, 255, 65, ${0.4 + portalPulse * 0.3})`
    ); // Daha parlak
    portalGradient.addColorStop(
      0.5,
      `rgba(0, 255, 65, ${0.2 + portalPulse * 0.2})`
    );
    portalGradient.addColorStop(1, "rgba(0, 255, 65, 0)");

    this.ctx.fillStyle = portalGradient;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Portal partikülleri
    this.portalParticles.forEach((p) => {
      this.ctx.fillStyle = `rgba(0, 255, 65, ${
        p.alpha * (1 - portalPulse * 0.5)
      })`; // Parlaklık ve kaybolma
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      this.ctx.fill();

      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.01; // Yavaşça kaybolur

      // Ekran dışına çıkarsa yeniden konumlandır
      if (
        p.alpha <= 0 ||
        p.x < 0 ||
        p.x > this.canvas.width ||
        p.y < 0 ||
        p.y > this.canvas.height
      ) {
        p.x = centerX + (Math.random() - 0.5) * 200; // Portal etrafında yeniden doğar
        p.y = centerY + (Math.random() - 0.5) * 200;
        p.radius = Math.random() * 2 + 0.5;
        p.vx = (Math.random() - 0.5) * 0.5;
        p.vy = (Math.random() - 0.5) * 0.5;
        p.alpha = 1;
      }
    });

    // UFO çizimi
    this.ctx.save();
    this.ctx.translate(this.ufoX, this.ufoY); // UFO'nun hareketli pozisyonu

    // UFO gövdesi
    this.ctx.fillStyle = "#00ff41";
    this.ctx.beginPath();
    this.ctx.ellipse(0, 0, 40, 15, 0, 0, Math.PI * 2);
    this.ctx.fill();

    // UFO üst kısmı
    this.ctx.fillStyle = "#39ff14";
    this.ctx.beginPath();
    this.ctx.ellipse(0, -8, 25, 12, 0, 0, Math.PI * 2);
    this.ctx.fill();

    // UFO ışıkları (daha belirgin parlama efekti)
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const x = Math.cos(angle) * 35;
      const y = Math.sin(angle) * 12;

      this.ctx.fillStyle = `rgba(255, 255, 255, ${
        0.7 + Math.sin(Date.now() * 0.015 + i) * 0.3
      })`; // Daha parlak ve hızlı titreşim
      this.ctx.beginPath();
      this.ctx.arc(x, y, 3, 0, Math.PI * 2);
      this.ctx.fill();
    }

    this.ctx.restore();
  }

  renderSimpsonsTheme() {
    // Bira şişesi çizimi
    const x = this.canvas.width - 150;
    const y = 100;

    this.ctx.save();
    this.ctx.translate(x, y);

    // Şişe gövdesi
    this.ctx.fillStyle = "#8B4513";
    this.ctx.fillRect(-15, 0, 30, 80);

    // Şişe boynu
    this.ctx.fillStyle = "#654321";
    this.ctx.fillRect(-8, -20, 16, 20);

    // Etiket
    this.ctx.fillStyle = "#FFD700";
    this.ctx.fillRect(-12, 20, 24, 30);

    // "DUFF" yazısı
    this.ctx.fillStyle = "#FF0000";
    this.ctx.font = "bold 10px Arial"; // Yazı boyutunu büyüttüm
    this.ctx.textAlign = "center";
    this.ctx.fillText("DUFF", 0, 38);

    // Kabarcık efekti (daha fazla ve daha hızlı)
    const bubbleCount = 15; // Kabarcık sayısını artırdım
    for (let i = 0; i < bubbleCount; i++) {
      const bubbleX = Math.sin(Date.now() * 0.008 + i * 0.5) * 8; // Daha geniş hareket
      const bubbleY = (Date.now() * 0.02 + i * 15) % 80; // Daha hızlı yükselme
      this.ctx.fillStyle = `rgba(255, 255, 255, ${
        0.4 + Math.sin(Date.now() * 0.015 + i) * 0.3
      })`;
      this.ctx.beginPath();
      this.ctx.arc(
        bubbleX,
        70 - bubbleY,
        Math.random() * 3 + 1,
        0,
        Math.PI * 2
      ); // Daha büyük kabarcıklar ve rastgele boyut
      this.ctx.fill();
    }

    this.ctx.restore();

    // "D'oh!" veya "Woohoo!" metin baloncukları
    const textBubbleInterval = 3000; // Her 3 saniyede bir
    const now = Date.now();
    if (now % textBubbleInterval < 50) {
      // Sadece kısa bir süre görünür
      const texts = ["D'oh!", "Woohoo!", "Ay, Caramba!"];
      const randomText = texts[Math.floor(Math.random() * texts.length)];
      const textX = Math.random() * this.canvas.width;
      const textY = Math.random() * (this.canvas.height - 100) + 50;

      this.ctx.fillStyle = "rgba(255, 255, 0, 0.8)"; // Sarı arka plan
      this.ctx.strokeStyle = "#000000";
      this.ctx.lineWidth = 2;
      this.ctx.font = "bold 20px Comic Sans MS";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";

      const textWidth = this.ctx.measureText(randomText).width;
      const padding = 10;
      const rectX = textX - textWidth / 2 - padding;
      const rectY = textY - 20;
      const rectWidth = textWidth + padding * 2;
      const rectHeight = 40;

      this.ctx.beginPath();
      this.ctx.roundRect(rectX, rectY, rectWidth, rectHeight, 10);
      this.ctx.fill();
      this.ctx.stroke();

      this.ctx.fillStyle = "#000000";
      this.ctx.fillText(randomText, textX, textY);
    }

    // Donut çizimi
    this.ctx.save();
    this.ctx.translate(this.donutX, this.donutY);
    this.ctx.rotate(Date.now() * 0.005); // Donut döner

    this.ctx.fillStyle = "#FFC0CB"; // Pembe
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 20, 0, Math.PI * 2);
    this.ctx.arc(0, 0, 10, 0, Math.PI * 2, true); // Ortadaki delik
    this.ctx.fill();

    // Renkli serpintiler
    const sprinkles = [
      { x: -10, y: -10, color: "#FF0000" },
      { x: 5, y: 15, color: "#00FF00" },
      { x: 12, y: -5, color: "#0000FF" },
      { x: -15, y: 8, color: "#FFFF00" },
    ];
    sprinkles.forEach((s) => {
      this.ctx.fillStyle = s.color;
      this.ctx.fillRect(s.x, s.y, 4, 8);
    });
    this.ctx.restore();
  }

  renderSouthParkTheme() {
    // Kar taneleri (daha yoğun ve belirgin)
    this.snowflakeParticles.forEach((s) => {
      this.ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha})`;
      this.ctx.beginPath();
      this.ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
      this.ctx.fill();

      s.y += s.vy;
      s.x += Math.sin(Date.now() * 0.001 + s.y * 0.01) * 0.5; // Yanlara doğru hafif sallanma

      if (s.y > this.canvas.height + s.radius) {
        s.y = -s.radius;
        s.x = Math.random() * this.canvas.width;
        s.radius = Math.random() * 3 + 1;
        s.vy = Math.random() * 1 + 0.5;
        s.alpha = Math.random() * 0.5 + 0.5;
      }
    });

    // Dağ silüeti (daha belirgin gölgelendirme)
    this.ctx.fillStyle = "rgba(255, 255, 255, 0.4)"; // Daha opak
    this.ctx.beginPath();
    this.ctx.moveTo(0, this.canvas.height);
    this.ctx.lineTo(0, this.canvas.height - 100);
    this.ctx.lineTo(200, this.canvas.height - 150);
    this.ctx.lineTo(400, this.canvas.height - 120);
    this.ctx.lineTo(600, this.canvas.height - 180);
    this.ctx.lineTo(800, this.canvas.height - 140);
    this.ctx.lineTo(this.canvas.width, this.canvas.height - 100);
    this.ctx.lineTo(this.canvas.width, this.canvas.height);
    this.ctx.closePath();
    this.ctx.fill();

    // Kenny'nin parka şapkası (masa kenarında)
    this.ctx.save();
    this.ctx.translate(this.canvas.width / 2, this.canvas.height - 30);
    this.ctx.fillStyle = "#FF8C00"; // Turuncu
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 25, Math.PI, 0, false); // Kafa kısmı
    this.ctx.lineTo(25, 20);
    this.ctx.lineTo(-25, 20);
    this.ctx.closePath();
    this.ctx.fill();

    this.ctx.fillStyle = "#000000"; // Gözler
    this.ctx.beginPath();
    this.ctx.arc(-8, -5, 3, 0, Math.PI * 2);
    this.ctx.arc(8, -5, 3, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();
  }

  renderFamilyGuyTheme() {
    // Tavuk çizimi (hareketli)
    const x = this.chickenX;
    const y = this.chickenY;
    const wingFlap = Math.sin(Date.now() * 0.012) * 8; // Daha hızlı ve geniş kanat çırpma animasyonu

    this.ctx.save();
    this.ctx.translate(x, y);

    // Tavuk gövdesi
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.ellipse(0, 0, 25, 35, 0, 0, Math.PI * 2);
    this.ctx.fill();

    // Tavuk kafası
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.arc(-5, -25, 15, 0, Math.PI * 2);
    this.ctx.fill();

    // Gaga
    this.ctx.fillStyle = "#FFA500";
    this.ctx.beginPath();
    this.ctx.moveTo(-15, -25 + wingFlap * 0.2);
    this.ctx.lineTo(-25, -22 + wingFlap * 0.2);
    this.ctx.lineTo(-15, -20 + wingFlap * 0.2);
    this.ctx.closePath();
    this.ctx.fill();

    // Taç
    this.ctx.fillStyle = "#FF0000";
    this.ctx.beginPath();
    this.ctx.moveTo(-10, -35 + wingFlap * 0.5);
    this.ctx.lineTo(-5, -45 + wingFlap * 0.5);
    this.ctx.lineTo(0, -35 + wingFlap * 0.5);
    this.ctx.lineTo(5, -40 + wingFlap * 0.5);
    this.ctx.lineTo(10, -35 + wingFlap * 0.5);
    this.ctx.lineTo(5, -30 + wingFlap * 0.5);
    this.ctx.lineTo(-10, -30 + wingFlap * 0.5);
    this.ctx.closePath();
    this.ctx.fill();

    // Kanatlar (daha belirgin hareketli)
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.ellipse(
      -20,
      -5,
      10,
      20,
      Math.PI / 4 + wingFlap * 0.08,
      0,
      Math.PI * 2
    ); // Daha geniş açı
    this.ctx.fill();
    this.ctx.beginPath();
    this.ctx.ellipse(
      20,
      -5,
      10,
      20,
      -Math.PI / 4 - wingFlap * 0.08,
      0,
      Math.PI * 2
    ); // Daha geniş açı
    this.ctx.fill();

    this.ctx.restore();

    // "Giggity" veya "Freakin' Sweet" metin baloncukları
    const textBubbleInterval = 4000; // Her 4 saniyede bir
    const now = Date.now();
    if (now % textBubbleInterval < 50) {
      // Sadece kısa bir süre görünür
      const texts = ["Giggity!", "Freakin' Sweet!", "Alright!"];
      const randomText = texts[Math.floor(Math.random() * texts.length)];
      const textX = Math.random() * this.canvas.width;
      const textY = Math.random() * (this.canvas.height - 100) + 50;

      this.ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
      this.ctx.strokeStyle = "#000000";
      this.ctx.lineWidth = 2;
      this.ctx.font = "bold 18px Arial";
      this.ctx.textAlign = "center";
      this.ctx.textBaseline = "middle";

      const textWidth = this.ctx.measureText(randomText).width;
      const padding = 10;
      const rectX = textX - textWidth / 2 - padding;
      const rectY = textY - 20;
      const rectWidth = textWidth + padding * 2;
      const rectHeight = 40;

      this.ctx.beginPath();
      this.ctx.roundRect(rectX, rectY, rectWidth, rectHeight, 10);
      this.ctx.fill();
      this.ctx.stroke();

      this.ctx.fillStyle = "#000000";
      this.ctx.fillText(randomText, textX, textY);
    }
  }

  renderFuturamaTheme() {
    // Robot kafası çizimi
    const x = this.canvas.width - 200;
    const y = 200;
    const blinkState = Math.floor(Date.now() / 150) % 15 === 0; // Daha sık göz kırpma
    const mouthState = Math.sin(Date.now() * 0.02) * 8; // Daha belirgin ağız hareketi

    this.ctx.save();
    this.ctx.translate(x, y);

    // Robot kafası
    this.ctx.fillStyle = "#C0C0C0";
    this.ctx.fillRect(-25, -30, 50, 40);

    // Gözler
    this.ctx.fillStyle = "#FFFF00";
    this.ctx.beginPath();
    if (!blinkState) {
      this.ctx.arc(-10, -15, 6, 0, Math.PI * 2);
      this.ctx.arc(10, -15, 6, 0, Math.PI * 2);
    } else {
      this.ctx.fillRect(-16, -16, 12, 2); // Kırpık göz
      this.ctx.fillRect(4, -16, 12, 2); // Kırpık göz
    }
    this.ctx.fill();

    // Ağız
    this.ctx.strokeStyle = "#000000";
    this.ctx.lineWidth = 3;
    this.ctx.beginPath();
    this.ctx.arc(0, 0 + mouthState * 0.5, 8, 0, Math.PI);
    this.ctx.stroke();

    // Antenler
    this.ctx.strokeStyle = "#C0C0C0";
    this.ctx.lineWidth = 2;
    this.ctx.beginPath();
    this.ctx.moveTo(-15, -30);
    this.ctx.lineTo(-15, -45);
    this.ctx.moveTo(15, -30);
    this.ctx.lineTo(15, -45);
    this.ctx.stroke();

    // Anten topları
    this.ctx.fillStyle = "#FF0000";
    this.ctx.beginPath();
    this.ctx.arc(-15, -45, 3, 0, Math.PI * 2);
    this.ctx.arc(15, -45, 3, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.restore();

    // Uzayda hareket eden yıldızlar (daha fazla ve daha hızlı)
    this.starfieldParticles.forEach((star) => {
      this.ctx.fillStyle = `rgba(255, 255, 255, ${
        star.alpha *
        (1 - Math.abs(Math.sin(Date.now() * 0.0005 + star.x * 0.01)))
      })`; // Titreme efekti
      this.ctx.beginPath();
      this.ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
      this.ctx.fill();

      star.x -= star.speed; // Sola doğru hareket
      if (star.x < 0) {
        star.x = this.canvas.width; // Ekranın sağına geri dön
        star.y = Math.random() * this.canvas.height;
        star.size = Math.random() * 2 + 0.5;
        star.speed = Math.random() * 0.3 + 0.1;
        star.alpha = Math.random();
      }
    });

    // Hafif nebula arka planı
    const nebulaGradient = this.ctx.createRadialGradient(
      this.canvas.width / 2,
      this.canvas.height / 2,
      0,
      this.canvas.width / 2,
      this.canvas.height / 2,
      Math.max(this.canvas.width, this.canvas.height) / 2
    );
    nebulaGradient.addColorStop(0, "rgba(255, 69, 0, 0.05)"); // Turuncu
    nebulaGradient.addColorStop(0.5, "rgba(0, 206, 209, 0.05)"); // Turkuaz
    nebulaGradient.addColorStop(1, "rgba(0, 0, 0, 0)");
    this.ctx.fillStyle = nebulaGradient;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Planet Express gemisi (hareketli)
    this.ctx.save();
    this.ctx.translate(this.ufoX, this.canvas.height - 100); // UFO'nun hareketini kullan
    this.ctx.fillStyle = "#FF0000";
    this.ctx.beginPath();
    this.ctx.moveTo(-50, 0);
    this.ctx.lineTo(0, -20);
    this.ctx.lineTo(50, 0);
    this.ctx.lineTo(0, 20);
    this.ctx.closePath();
    this.ctx.fill();
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 10, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();
  }

  renderAvatarTheme() {
    // 4 element sembolü
    const centerX = this.canvas.width / 2;
    const centerY = this.canvas.height / 2;
    const animationOffset = Math.sin(Date.now() * 0.005) * 8; // Daha belirgin hareket

    // Ateş (kırmızı) - titreme efekti
    this.ctx.fillStyle = `rgba(255, 0, 0, ${
      0.4 + Math.abs(Math.sin(Date.now() * 0.01)) * 0.3
    })`; // Daha parlak ve hızlı titreşim
    this.ctx.beginPath();
    this.ctx.moveTo(centerX - 50, centerY - 50 + animationOffset);
    this.ctx.lineTo(centerX - 30, centerY - 80 + animationOffset * 1.8); // Daha geniş titreme
    this.ctx.lineTo(centerX - 10, centerY - 50 + animationOffset);
    this.ctx.closePath();
    this.ctx.fill();

    // Su (mavi) - dalgalanma efekti
    this.ctx.fillStyle = `rgba(0, 0, 255, ${
      0.4 + Math.abs(Math.sin(Date.now() * 0.008)) * 0.3
    })`;
    this.ctx.beginPath();
    this.ctx.arc(
      centerX + 50,
      centerY - 50 + animationOffset * 0.7,
      25,
      0,
      Math.PI * 2
    ); // Daha büyük dalgalanma
    this.ctx.fill();

    // Toprak (yeşil) - hafif sallanma
    this.ctx.fillStyle = `rgba(0, 128, 0, ${
      0.4 + Math.abs(Math.sin(Date.now() * 0.006)) * 0.3
    })`;
    this.ctx.fillRect(
      centerX - 70 + animationOffset * 0.5,
      centerY + 30,
      45,
      45
    ); // Daha büyük ve hareketli
    this.ctx.fillRect(
      centerX - 70 + animationOffset * 0.5 + 5,
      centerY + 30 + 5,
      35,
      35
    ); // İç gölge

    // Hava (sarı) - dönme efekti
    this.ctx.strokeStyle = `rgba(255, 165, 0, ${
      0.6 + Math.abs(Math.sin(Date.now() * 0.009)) * 0.4
    })`;
    this.ctx.lineWidth = 6;
    this.ctx.save();
    this.ctx.translate(centerX + 50, centerY + 50);
    this.ctx.rotate(Date.now() * 0.002); // Daha hızlı dönme
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 30, 0, Math.PI * 2); // Daha büyük
    this.ctx.stroke();
    this.ctx.restore();

    // Element sembollerinin etrafında hafif parıltı
    this.ctx.shadowColor = "rgba(255, 255, 255, 0.5)";
    this.ctx.shadowBlur = 10;
    this.ctx.fillStyle = "transparent"; // Sadece gölge için

    // Ateş sembolü etrafında parıltı
    this.ctx.beginPath();
    this.ctx.arc(centerX - 30, centerY - 65, 40, 0, Math.PI * 2);
    this.ctx.fill();

    // Su sembolü etrafında parıltı
    this.ctx.beginPath();
    this.ctx.arc(centerX + 50, centerY - 50, 40, 0, Math.PI * 2);
    this.ctx.fill();

    // Toprak sembolü etrafında parıltı
    this.ctx.beginPath();
    this.ctx.arc(centerX - 47.5, centerY + 52.5, 40, 0, Math.PI * 2);
    this.ctx.fill();

    // Hava sembolü etrafında parıltı
    this.ctx.beginPath();
    this.ctx.arc(centerX + 50, centerY + 50, 40, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.shadowBlur = 0;
  }

  renderPokemonTheme() {
    // Pokéball çizimi
    const x = this.canvas.width / 2;
    const y = this.canvas.height / 2;
    const pulse = (Math.sin(Date.now() * 0.008) + 1) / 2; // Daha hızlı nabız efekti

    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.scale(1 + pulse * 0.03, 1 + pulse * 0.03); // Daha belirgin büyüme/küçülme

    // Üst yarım (kırmızı)
    this.ctx.fillStyle = "#FF0000";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 40, Math.PI, 0, false);
    this.ctx.fill();

    // Alt yarım (beyaz)
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 40, 0, Math.PI, false);
    this.ctx.fill();

    // Orta çizgi
    this.ctx.strokeStyle = "#000000";
    this.ctx.lineWidth = 4;
    this.ctx.beginPath();
    this.ctx.moveTo(-40, 0);
    this.ctx.lineTo(40, 0);
    this.ctx.stroke();

    // Orta daire
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 12, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.strokeStyle = "#000000";
    this.ctx.lineWidth = 2;
    this.ctx.stroke();

    // İç daire
    this.ctx.fillStyle = "#000000";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 6, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.restore();

    // Pikachu kuyruğu (masa kenarında)
    this.ctx.save();
    this.ctx.translate(50, this.canvas.height - 50);
    this.ctx.rotate(-Math.PI / 8 + Math.sin(Date.now() * 0.01) * 0.1); // Hafif sallanma

    this.ctx.fillStyle = "#FFD700"; // Sarı
    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.lineTo(30, -20);
    this.ctx.lineTo(20, -40);
    this.ctx.lineTo(50, -60);
    this.ctx.lineTo(40, -80);
    this.ctx.lineTo(0, -50);
    this.ctx.closePath();
    this.ctx.fill();

    this.ctx.fillStyle = "#000000"; // Siyah uç
    this.ctx.beginPath();
    this.ctx.moveTo(30, -20);
    this.ctx.lineTo(20, -40);
    this.ctx.lineTo(25, -30);
    this.ctx.closePath();
    this.ctx.fill();
    this.ctx.restore();
  }

  renderDragonBallTheme() {
    // Dragon Ball çizimi
    const x = 200;
    const y = 200;

    this.ctx.save();
    this.ctx.translate(x, y);

    // Top
    this.ctx.fillStyle = "#FFA500";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 30, 0, Math.PI * 2);
    this.ctx.fill();

    // Yıldızlar (daha belirgin parlama efekti)
    for (let i = 0; i < 4; i++) {
      const angle = (i / 4) * Math.PI * 2;
      const starX = Math.cos(angle) * 15;
      const starY = Math.sin(angle) * 15;
      const twinkleAlpha = 0.6 + Math.sin(Date.now() * 0.008 + i) * 0.4; // Daha belirgin titreşim

      this.ctx.fillStyle = `rgba(255, 0, 0, ${twinkleAlpha})`;
      this.ctx.beginPath();
      this.ctx.moveTo(starX, starY - 5);
      this.ctx.lineTo(starX + 2, starY - 2);
      this.ctx.lineTo(starX + 5, starY);
      this.ctx.lineTo(starX + 2, starY + 2);
      this.ctx.lineTo(starX, starY + 5);
      this.ctx.lineTo(starX - 2, starY + 2);
      this.ctx.lineTo(starX - 5, starY);
      this.ctx.lineTo(starX - 2, starY - 2);
      this.ctx.closePath();
      this.ctx.fill();
    }

    this.ctx.restore();

    // Ki Aura efekti (cue ball etrafında)
    if (this.cueBall && !this.cueBall.inPocket) {
      const auraRadius = this.cueBall.radius + this.kiAuraStrength * 20; // Aura boyutu
      const auraAlpha = this.kiAuraStrength * 0.5; // Aura şeffaflığı

      const auraGradient = this.ctx.createRadialGradient(
        this.cueBall.x,
        this.cueBall.y,
        this.cueBall.radius,
        this.cueBall.x,
        this.cueBall.y,
        auraRadius
      );
      auraGradient.addColorStop(0, `rgba(255, 255, 0, ${auraAlpha})`); // Sarı
      auraGradient.addColorStop(0.5, `rgba(255, 165, 0, ${auraAlpha * 0.7})`); // Turuncu
      auraGradient.addColorStop(1, `rgba(255, 69, 0, 0)`); // Kırmızı

      this.ctx.fillStyle = auraGradient;
      this.ctx.beginPath();
      this.ctx.arc(this.cueBall.x, this.cueBall.y, auraRadius, 0, Math.PI * 2);
      this.ctx.fill();
    }
  }

  renderNarutoTheme() {
    // Ninja yıldızı (shuriken)
    const x = this.canvas.width - 150;
    const y = 150;

    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.rotate(this.shurikenRotation * 1.5); // Daha hızlı dönme

    this.ctx.fillStyle = "#C0C0C0";
    for (let i = 0; i < 4; i++) {
      this.ctx.save();
      this.ctx.rotate((i / 4) * Math.PI * 2);

      this.ctx.beginPath();
      this.ctx.moveTo(0, -5);
      this.ctx.lineTo(25, -8);
      this.ctx.lineTo(30, 0);
      this.ctx.lineTo(25, 8);
      this.ctx.lineTo(0, 5);
      this.ctx.closePath();
      this.ctx.fill();

      this.ctx.restore();
    }

    // Merkez delik
    this.ctx.fillStyle = "#000000";
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 8, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.restore();

    // Uçan yaprak partikülleri
    this.leafParticles.forEach((leaf) => {
      this.ctx.save();
      this.ctx.translate(leaf.x, leaf.y);
      this.ctx.rotate(leaf.rotation);

      this.ctx.fillStyle = `rgba(139, 69, 19, ${leaf.alpha})`; // Kahverengi yaprak
      this.ctx.beginPath();
      this.ctx.ellipse(0, 0, leaf.size, leaf.size / 2, 0, 0, Math.PI * 2);
      this.ctx.fill();

      this.ctx.restore();

      leaf.y += leaf.speed;
      leaf.x += Math.sin(leaf.y * 0.05) * 0.5; // Hafif yanal hareket
      leaf.rotation += leaf.rotationSpeed;

      if (leaf.y > this.canvas.height + leaf.size) {
        leaf.y = -leaf.size;
        leaf.x = Math.random() * this.canvas.width;
        leaf.speed = Math.random() * 0.5 + 0.2;
        leaf.rotation = Math.random() * Math.PI * 2;
        leaf.rotationSpeed = (Math.random() - 0.5) * 0.05;
        leaf.alpha = Math.random() * 0.5 + 0.5;
      }
    });

    // Konoha Köyü sembolü (sol üst köşede)
    this.ctx.save();
    this.ctx.translate(80, 80);
    this.ctx.strokeStyle = "#000080"; // Koyu mavi
    this.ctx.lineWidth = 5;
    this.ctx.lineCap = "round";

    // Spiral
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 30, Math.PI * 0.75, Math.PI * 2.25);
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(0, -30);
    this.ctx.lineTo(0, 30);
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(-25, 0);
    this.ctx.lineTo(25, 0);
    this.ctx.stroke();

    this.ctx.restore();
  }

  renderOnePieceTheme() {
    // Korsan bayrağı
    const x = 150;
    const y = 100;

    this.ctx.save();
    this.ctx.translate(x, y);

    // Bayrak direği
    this.ctx.strokeStyle = "#8B4513";
    this.ctx.lineWidth = 4;
    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.lineTo(0, 100);
    this.ctx.stroke();

    // Bayrak
    this.ctx.fillStyle = "#000000";
    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.lineTo(60, 0 + this.flagWaveOffset * 1.5); // Daha belirgin dalgalanma
    this.ctx.lineTo(60, 40 - this.flagWaveOffset * 1.5);
    this.ctx.lineTo(0, 40);
    this.ctx.closePath();
    this.ctx.fill();

    // Kuru kafa
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.beginPath();
    this.ctx.arc(30, 20, 12, 0, Math.PI * 2);
    this.ctx.fill();

    // Göz çukurları
    this.ctx.fillStyle = "#000000";
    this.ctx.beginPath();
    this.ctx.arc(26, 16, 3, 0, Math.PI * 2);
    this.ctx.arc(34, 16, 3, 0, Math.PI * 2);
    this.ctx.fill();

    // Çapraz kemikler
    this.ctx.strokeStyle = "#FFFFFF";
    this.ctx.lineWidth = 3;
    this.ctx.beginPath();
    this.ctx.moveTo(15, 25);
    this.ctx.lineTo(45, 35);
    this.ctx.moveTo(45, 25);
    this.ctx.lineTo(15, 35);
    this.ctx.stroke();

    this.ctx.restore();

    // Hasır Şapka (masa kenarında)
    this.ctx.save();
    this.ctx.translate(this.canvas.width - 80, 50);
    this.ctx.rotate(Math.PI / 12 + Math.sin(Date.now() * 0.005) * 0.05); // Hafif sallanma

    this.ctx.fillStyle = "#D2B48C"; // Hasır rengi
    this.ctx.beginPath();
    this.ctx.ellipse(0, 0, 30, 15, 0, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.fillStyle = "#8B0000"; // Kırmızı bant
    this.ctx.beginPath();
    this.ctx.arc(0, 0, 15, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();

    // Going Merry veya Thousand Sunny silüeti (hareketli)
    this.ctx.save();
    this.ctx.translate(this.shipX, this.shipY);
    this.ctx.fillStyle = "rgba(0, 0, 0, 0.3)"; // Gölge silüeti

    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.lineTo(50, -20);
    this.ctx.lineTo(150, -20);
    this.ctx.lineTo(200, 0);
    this.ctx.lineTo(180, 20);
    this.ctx.lineTo(20, 20);
    this.ctx.closePath();
    this.ctx.fill();

    this.ctx.beginPath(); // Yelken
    this.ctx.moveTo(100, -20);
    this.ctx.lineTo(100, -70);
    this.ctx.lineTo(130, -50);
    this.ctx.closePath();
    this.ctx.fill();

    this.ctx.restore();
  }

  renderNeonTheme() {
    // Neon çizgiler
    this.ctx.strokeStyle = "#00FFFF";
    this.ctx.lineWidth = 3; // Daha kalın çizgiler
    this.ctx.shadowColor = "#00FFFF";
    this.ctx.shadowBlur = 15; // Daha belirgin parlama

    // Grid pattern
    const lineOffset = (Date.now() * 0.02) % 50; // Daha hızlı kayma
    for (let i = 0; i < this.canvas.width; i += 50) {
      this.ctx.beginPath();
      this.ctx.moveTo(i + lineOffset, 0);
      this.ctx.lineTo(i + lineOffset, this.canvas.height);
      this.ctx.stroke();
    }

    for (let i = 0; i < this.canvas.height; i += 50) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, i + lineOffset);
      this.ctx.lineTo(this.canvas.width, i + lineOffset);
      this.ctx.stroke();
    }

    // Pulsating geometric shapes
    const pulseAlpha = (Math.sin(Date.now() * 0.005) + 1) / 2;
    this.ctx.shadowColor = `rgba(0, 255, 255, ${pulseAlpha})`;
    this.ctx.shadowBlur = 20;

    this.ctx.strokeStyle = `rgba(0, 255, 255, ${0.5 + pulseAlpha * 0.5})`;
    this.ctx.lineWidth = 2;

    // Center square
    const squareSize = 100 + pulseAlpha * 20;
    this.ctx.beginPath();
    this.ctx.rect(
      this.canvas.width / 2 - squareSize / 2,
      this.canvas.height / 2 - squareSize / 2,
      squareSize,
      squareSize
    );
    this.ctx.stroke();

    // Corner triangles
    const triangleSize = 50 + pulseAlpha * 10;
    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.lineTo(triangleSize, 0);
    this.ctx.lineTo(0, triangleSize);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(this.canvas.width, 0);
    this.ctx.lineTo(this.canvas.width - triangleSize, 0);
    this.ctx.lineTo(this.canvas.width, triangleSize);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(0, this.canvas.height);
    this.ctx.lineTo(triangleSize, this.canvas.height);
    this.ctx.lineTo(0, this.canvas.height - triangleSize);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(this.canvas.width, this.canvas.height);
    this.ctx.lineTo(this.canvas.width - triangleSize, this.canvas.height);
    this.ctx.lineTo(this.canvas.width, this.canvas.height - triangleSize);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.shadowBlur = 0;
  }

  renderGoldTheme() {
    // Altın parıltılar
    for (let i = 0; i < 50; i++) {
      // Daha fazla parıltı
      const x = Math.random() * this.canvas.width;
      const y = Math.random() * this.canvas.height;
      const size = Math.random() * 7 + 3; // Daha büyük parıltılar
      const alpha = 0.5 + Math.sin(Date.now() * 0.008 + i) * 0.4; // Daha belirgin parlama efekti

      this.ctx.fillStyle = `rgba(255, 215, 0, ${alpha})`;
      this.ctx.shadowColor = "#FFD700";
      this.ctx.shadowBlur = 8; // Daha belirgin gölge
      this.ctx.beginPath();
      this.ctx.arc(x, y, size, 0, Math.PI * 2);
      this.ctx.fill();
    }
    this.ctx.shadowBlur = 0;

    // Altın kenar parlaklığı
    const goldPulse = (Math.sin(Date.now() * 0.007) + 1) / 2;
    this.ctx.strokeStyle = `rgba(255, 215, 0, ${0.8 + goldPulse * 0.2})`;
    this.ctx.lineWidth = 6;
    this.ctx.shadowColor = "#FFD700";
    this.ctx.shadowBlur = 10 + goldPulse * 5;
    this.ctx.strokeRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.shadowBlur = 0;
  }

  renderSilverTheme() {
    // Gümüş parıltılar
    for (let i = 0; i < 40; i++) {
      // Daha fazla parıltı
      const x = Math.random() * this.canvas.width;
      const y = Math.random() * this.canvas.height;
      const size = Math.random() * 6 + 2; // Daha büyük parıltılar
      const alpha = 0.4 + Math.sin(Date.now() * 0.009 + i) * 0.4; // Daha belirgin parlama efekti

      this.ctx.fillStyle = `rgba(192, 192, 192, ${alpha})`;
      this.ctx.shadowColor = "#C0C0C0";
      this.ctx.shadowBlur = 6; // Daha belirgin gölge
      this.ctx.beginPath();
      this.ctx.arc(x, y, size, 0, Math.PI * 2);
      this.ctx.fill();
    }
    this.ctx.shadowBlur = 0;

    // Gümüş kenar parlaklığı
    const silverPulse = (Math.sin(Date.now() * 0.006) + 1) / 2;
    this.ctx.strokeStyle = `rgba(192, 192, 192, ${0.8 + silverPulse * 0.2})`;
    this.ctx.lineWidth = 6;
    this.ctx.shadowColor = "#C0C0C0";
    this.ctx.shadowBlur = 10 + silverPulse * 5;
    this.ctx.strokeRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.shadowBlur = 0;
  }

  lightenColor(color, percent) {
    const num = Number.parseInt(color.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = ((num >> 8) & 0x00ff) + amt;
    const B = (num & 0x0000ff) + amt;
    return (
      "#" +
      (
        0x1000000 +
        (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
        (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
        (B < 255 ? (B < 1 ? 0 : B) : 255)
      )
        .toString(16)
        .slice(1)
    );
  }

  darkenColor(color, percent) {
    const num = Number.parseInt(color.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) - amt;
    const G = ((num >> 8) & 0x00ff) - amt;
    const B = (num & 0x0000ff) - amt;
    return (
      "#" +
      (
        0x1000000 +
        (R > 255 ? 255 : R < 0 ? 0 : R) * 0x10000 +
        (G > 255 ? 255 : G < 0 ? 0 : G) * 0x100 +
        (B > 255 ? 255 : B < 0 ? 0 : B)
      )
        .toString(16)
        .slice(1)
    );
  }

  gameLoop() {
    this.updatePhysics();
    this.render();
    requestAnimationFrame(() => this.gameLoop());
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new BilliardsGame();
});
